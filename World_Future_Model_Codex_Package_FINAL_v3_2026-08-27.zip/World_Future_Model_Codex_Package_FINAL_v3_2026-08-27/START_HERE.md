# START HERE — World Future Modeling System

This ZIP is a Codex-ready specification + research package for building a living world-modeling application.

The tool models four different futures at once:
1. National power
2. Economic/productive capacity
3. Median-citizen life
4. Ownership / beneficiaries

Read first:
1. `codex/CODEX_MASTER_PROMPT.md`
2. `docs/PRODUCT_SPEC.md`
3. `docs/MODEL_ENGINE.md`
4. `data/model_config.json`
5. `data/country_registry_197.csv`
6. `data/future_influence_blocs.json`
7. `data/core_scenarios.csv`
8. `data/causal_rules.json`
9. `research/DEEP_RESEARCH_V2_REPORT.md`

The package includes 197 country/economy seeds, 27 model dimensions, development-project logic, geopolitical influence systems, multipolar/bipolar scenarios, domestic beneficiary groups, demographic/household feedback loops, evidence rules and the prior World Systems Atlas as optional reference material.

Important: quantitative scores are analyst models, not facts. The software must expose sources, confidence, weight sensitivity and missing data.


## v2.1 additions
Read `CHANGELOG_v2_1.md` and `docs/TECHNOLOGY_SOVEREIGNTY_AND_DOMESTIC_IP.md`. The model now includes domestic product/IP formation and a broader cross-country technology-modernization project sweep.


## FINAL v3
Adds urban opportunity access, housing exclusion, fiscal aging/pensions, natural-vs-migration demographics, demographic composition/integration, bloc coordination, industrial displacement, resource-escape, experienced prosperity and subnational convergence.
