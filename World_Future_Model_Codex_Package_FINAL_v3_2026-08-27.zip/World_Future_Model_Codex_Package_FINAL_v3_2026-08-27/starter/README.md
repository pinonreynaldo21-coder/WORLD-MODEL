Starter TypeScript model interfaces/helpers only. Codex should build from the master prompt.
