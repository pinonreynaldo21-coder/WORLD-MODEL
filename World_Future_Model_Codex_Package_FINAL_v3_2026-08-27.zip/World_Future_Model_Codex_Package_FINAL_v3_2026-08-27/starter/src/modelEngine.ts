export const mean = (xs: Array<number|null|undefined>) => {
  const vals = xs.filter((x): x is number => typeof x === 'number' && Number.isFinite(x));
  return vals.length ? vals.reduce((a,b)=>a+b,0)/vals.length : null;
};
export function computeIndexes(s: Record<string, number|null>) {
  const nationalCapability = mean([s.national_power,s.technology_adaptation,s.technology_ownership,s.manufacturing_depth,s.state_capacity,s.energy_position,s.capital_finance]);
  const developmentMomentum = mean([s.economic_development_potential,s.technology_adaptation,s.state_capacity,s.regulatory_efficiency,s.human_capital,s.labor_absorption,s.brain_gain_retention,s.development_pipeline_momentum,s.project_execution_capacity,s.geographic_market_access]);
  const citizenCapture = mean([s.median_citizen_prosperity,s.housing_household_formation,s.resource_rent_distribution,s.human_capital,s.labor_absorption,s.political_social_stability,s.domestic_value_capture]);
  const globalFuturesIndex = nationalCapability!==null && developmentMomentum!==null && citizenCapture!==null ? .45*nationalCapability+.35*developmentMomentum+.20*citizenCapture : null;
  return {nationalCapability,developmentMomentum,citizenCapture,globalFuturesIndex};
}
