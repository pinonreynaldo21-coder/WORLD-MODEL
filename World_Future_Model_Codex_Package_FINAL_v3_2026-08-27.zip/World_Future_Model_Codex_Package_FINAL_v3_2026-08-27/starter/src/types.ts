export type EvidenceGrade = 'A' | 'B' | 'C';
export type CountryConfidence = 'A' | 'B' | 'C';
export interface CountryModel {
  country: string;
  iso3: string;
  region: string;
  confidence: CountryConfidence;
  as_of: string;
  archetypes: string[];
  thesis?: string;
  scores: Record<string, number | null>;
  trajectories: Record<'2030'|'2040'|'2050', string>;
}
