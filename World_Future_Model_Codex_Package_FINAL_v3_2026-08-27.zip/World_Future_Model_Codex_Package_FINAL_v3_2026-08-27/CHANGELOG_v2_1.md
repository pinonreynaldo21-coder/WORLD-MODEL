# CHANGELOG — v2.1 (26 Aug 2026)

## Added
- Olinia 1 / Carga as explicit Mexican domestic-product nodes.
- Olinia battery pack/electronics + Puebla battery-localization path.
- Coatlicue sovereign supercomputer.
- NubeMX/public data-center/GPU cloud strategy.
- Kutsari semiconductor design/labs/fab pathway.
- QSM Querétaro semiconductor production.
- Expanded global technology-modernization search.
- New global comparison table covering India, Brazil, Saudi Arabia, UAE, Vietnam, Malaysia, Türkiye, Morocco, South Korea, Japan, Nigeria and Indonesia.
- Three model dimensions:
  - Domestic Brand / IP Creation
  - Strategic Technology Sovereignty
  - Industrial Value-Chain Closure
- Domestic-product maturity ladder.
- Mexico-vs-global benchmark table.

## Philosophy change
The model now explicitly distinguishes:
foreign-owned assembly
from
domestic supplier formation
from
domestic engineering/IP
from
scaled domestic brands
from
full strategic technology stacks.

This prevents both under-crediting emerging domestic technological capability and over-crediting government announcements/prototypes.
