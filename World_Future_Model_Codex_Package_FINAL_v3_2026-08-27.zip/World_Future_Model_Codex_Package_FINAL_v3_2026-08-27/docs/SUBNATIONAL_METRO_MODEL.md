# Subnational / Metro Convergence Layer

Country averages can conceal the real experience. Priority metros/states include Mexico (Querétaro, Monterrey/Nuevo León, Bajío, CDMX, border states, Jalisco, poorer south), US states, Chinese coastal/interior regions, Indian states, Spain (Madrid/Catalonia/Basque/Andalusia), France (Paris vs secondary metros), Italy north/south and Brazil regions.

Metro variables: high-skill job density, wages, housing, home size, commute/transit, construction, firms, universities, safety, international links, industrial pipeline, young-adult independence and family formation.

Build a Developed-Lifestyle Convergence view comparing cost/asset/service-adjusted middle-class lives across countries.
