# Research Backlog

P0
- real 2000–2025 historical panel
- replace C-confidence country priors
- global infrastructure/project database
- electricity/grid/compute dataset
- fertility/marriage/household/housing panel
- technology-ownership accounts
- AI/robot labor exposure by country
- subnational models: US, China, India, Mexico, EU

P1
- diaspora capital/skill transfer
- critical-mineral value chains
- sovereign wealth / household equity ownership
- housing permitting/construction
- migration quality/return migration
- climate/water adaptation
- logistics corridors
- defense-industrial capacity
