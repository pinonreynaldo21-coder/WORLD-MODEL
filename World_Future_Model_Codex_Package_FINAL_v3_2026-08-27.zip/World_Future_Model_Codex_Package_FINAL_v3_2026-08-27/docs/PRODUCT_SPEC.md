# Product Specification — World Future Model

## Core question
Which societies can convert technology, energy, capital, demographics, resources, geography and institutions into sustained national power AND broad improvements in ordinary human living standards?

## Flagship surfaces
1. World Map — metric + year + scenario.
2. Country Deep Dive — mechanisms, projects, people outcome, evidence.
3. Region View — intra-region divergence.
4. Development Pipeline — project stages and execution.
5. Future Influence Blocs — formal blocs, production systems, swing regions, influence arenas.
6. Scenario Lab — AI, robotics, energy, geopolitics, fertility, migration.
7. Country vs Citizen — power/productivity vs median household outcome.
8. Beneficiary Map — countries + domestic groups.
9. Evidence & Confidence — sourced facts vs model inference.

## Never collapse
- GDP into household welfare.
- technology use into technology ownership.
- resources into domestic value capture.
- youth population into automatic demographic dividend.
- regime type into state capacity.
- project announcement into delivered infrastructure.


## Strategic Technology Sovereignty
Add a dedicated view showing each country's progression from:
foreign assembly → supplier depth → domestic design/IP → scaled domestic brands → core-component/full-stack capability.

Show sovereign/public compute, domestic cloud, semiconductors, EV/robotics/aerospace products, batteries and indigenous AI models.
