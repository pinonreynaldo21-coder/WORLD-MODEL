# Strategic Technology Sovereignty & Domestic Product Formation

The model previously risked giving too much credit to **foreign-owned assembly** and too little credit to countries that are beginning to **design and own products, technology and core components**.

## Product / IP ladder

### Stage 1 — Assembly
Foreign design, brand and critical components; local labor/plant.

### Stage 2 — Local supplier formation
Increasing domestic components, tooling, maintenance, engineering and process know-how.

### Stage 3 — Domestic design / platform formation
Local engineers design products, batteries, software, chips or subsystems. Domestic patents/IP begin to matter.

### Stage 4 — Scaled domestic brand / ecosystem
Domestic brand reaches meaningful commercial scale and builds suppliers, software, services and export capability.

### Stage 5 — Full strategic stack
Domestic firms control brands/IP plus significant core components/platforms and compete globally.

Do not equate a government-branded prototype with Stage 4. Commercial scale and supplier localization matter.

## New metrics

- `domestic_brand_ip_creation`
- `strategic_technology_sovereignty`
- `industrial_value_chain_closure`

These complement—not replace—technology adoption and ownership.

## Mexico
Olinia is meaningful because Mexico already has a 4M+ vehicle/year automotive base. The experiment is whether it can move from foreign-led production toward its own design/IP, battery pack/electronics, suppliers and brands.

Coatlicue, NubeMX, Kutsari and QSM similarly test whether Mexico can develop sovereign/public compute and semiconductor capability rather than only importing digital infrastructure.

## Fairness rule
Whenever Mexico receives credit for a domestic project, benchmark it against real peers:
- Togg / Türkiye
- VinFast / Vietnam
- Proton / Malaysia
- Ceer / Saudi Arabia
- Neo Motors / Morocco
- India domestic auto + AI/semiconductor programs
- Japan/Korea/China frontier domestic ecosystems

The tool should display **maturity stage + actual production + domestic content + technology ownership + source**, not patriotic claims.
