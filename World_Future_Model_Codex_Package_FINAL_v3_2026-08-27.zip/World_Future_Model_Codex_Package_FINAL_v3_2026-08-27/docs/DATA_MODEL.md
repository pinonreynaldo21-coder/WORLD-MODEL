# Data Model

Recommended entities:
countries
metric_definitions
observations
model_scores
projects
project_updates
scenarios
scenario_shocks
country_scenario_results
blocs
bloc_memberships
trade_dependencies
technology_dependencies
demographic_series
population_group_results
sources
claims

Every claim should support:
claim text, geography, evidence-for, evidence-against, confidence, sources, last-reviewed and falsification indicators.
