# UI / UX

Style: Financial Times + Bloomberg + modern geopolitical intelligence dashboard.

Home:
world choropleth, metric/year/scenario selector, top risers/decliners, modernization momentum, influence blocs.

Country:
scorecard, mechanisms, timeline, projects, demographics, technology, industry, energy, resources, household outcomes, scenarios, evidence.

Scenario Lab:
sliders left; map/ranks right; show WHY each country changed.

Bloc map:
stable geographic layers and corridors, not a force graph.

Mobile:
search-first, map zoom, country cards, no unreadable mega-tables.

Accessibility:
keyboard, color + symbols, high contrast, reduced motion.
