# Model Engine Specification

Keep raw variables, normalized scores, composites and scenario outputs separate.

## Project effect
project_effect = stage_weight × execution_probability × scale_to_gdp × bottleneck_removal × network_effects × domestic_value_capture

Stage weights:
announced .10
funded .30
tendered .45
under construction .70
partially operational .85
operational 1.00
paused .05
cancelled 0

Cap any single megaproject contribution.

## Scenario propagation
Modify drivers, then recompute outputs. Do not directly hand-edit final rank.

## Distribution engine
For each shock estimate effects on:
capital owners, median workers, routine white collar, technical workers, manufacturing workers, youth, homeowners, renters, pensioners, resource owners, migrants/diaspora, small businesses.

## Demographics
Model fertility + migration + retirement + labor participation + automation + productivity.

## Social reproduction
housing + youth earnings/jobs + partnership/marriage + childcare + preferences → household formation / fertility.

## State capacity
Execution, competence, corruption, feedback/error correction, legal predictability and private-sector dynamism are separate variables.

## Explainability
Every score change needs a reason tree.
