# Update Protocol

Never overwrite history. Append dated observations and version scores.

Regular sources:
IMF, World Bank, OECD, UN, ILO, Eurostat/national statistics, Stanford AI Index, WIPO, IFR, IEA, IRENA, USGS, central banks, project agencies and credible current reporting.

Every project must move through an explicit status:
announced → funded → tendered → construction → partial → operational
or paused/cancelled.

Change structural scores only when new evidence, project progress/failure or major shocks justify it. Store the reason.
