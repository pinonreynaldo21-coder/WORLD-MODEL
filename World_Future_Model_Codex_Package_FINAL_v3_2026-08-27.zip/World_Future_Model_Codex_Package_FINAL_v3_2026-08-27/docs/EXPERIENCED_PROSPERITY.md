# Experienced Prosperity & Poverty-to-Security Ladder

GDP per capita is not enough. Build lived prosperity from housing space/quality, housing burden, consumption after essentials, healthcare, transport, utilities, safety, debt, leisure/work hours, family care, assets, services and local prices.

Prosperity ladder:
0 severe deprivation
1 extreme-poverty escape
2 basic material security
3 vulnerable lower-middle
4 secure emerging-market middle class
5 developed-country material standard
6 affluent/capital-owning household

Levels 4–6 must be multidimensional, not merely PPP-dollar cutoffs.

Every country and metro needs CURRENT LIVING STANDARD plus TRAJECTORY / OPPORTUNITY PREMIUM.
