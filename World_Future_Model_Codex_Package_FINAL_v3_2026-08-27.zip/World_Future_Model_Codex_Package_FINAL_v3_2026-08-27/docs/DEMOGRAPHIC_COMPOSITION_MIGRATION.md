# Demographic Composition, Migration & Integration

Decompose total population change into natural increase (births-deaths) and net migration. Track native-born/foreign-born, citizenship, broad origin, age, language, first/second generation, employment/education outcomes and—where reliable—religion.

Composition is descriptive, not a quality ranking. Never infer productivity, crime, ideology or social compatibility from ethnicity or religion alone. Future identity composition must be scenario-based because migration policy, fertility convergence, intermarriage, secularization and self-identification can change.

Spain is a flagship: population can rise while Spain-born population falls because foreign-born growth offsets decline. Spain has no official religion census; Muslim-population estimates must show their non-official source status. Pew's older religion projections are scenario exercises, not current deterministic forecasts.

For the United States, track Hispanic share separately from specific origin. Mexican origin is currently the largest Hispanic-origin group; do not assume its 2050 share without a source.
