# Final Missing Dimensions Audit — v3

1 Urban opportunity concentration
2 Housing supply elasticity
3 Agglomeration exclusion/spatial inequality
4 Pension/fiscal aging
5 Natural population change vs migration
6 Migration demographic dependence
7 Demographic composition change
8 Migrant/second-generation integration
9 Bloc coordination/veto friction
10 Industrial moat durability
11 Foreign competitive displacement
12 Infrastructure gaps
13 Investment/legal/regulatory risk
14 Resource-economy escape probability
15 Internal regional divergence
16 Experienced living standard
17 Leisure/family-support value
18 Current level vs trajectory
19 Broad middle-class security, not binary poverty
20 Fiscal/monetary flexibility
21 Domestic firm scaling

Culture, religion, ethnicity, happiness and political ideology are not collapsed into inherent quality scores. They may affect outcomes through measurable channels only.
