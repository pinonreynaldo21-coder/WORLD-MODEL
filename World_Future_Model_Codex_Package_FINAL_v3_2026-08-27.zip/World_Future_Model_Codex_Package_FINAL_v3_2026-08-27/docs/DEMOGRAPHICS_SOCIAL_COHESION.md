# Demographics, Relationships, Household Formation & Social Cohesion

Track where credible:
TFR, births, age structure, marriage, age at marriage, never-married share, cohabitation, childlessness, living alone, young adults with parents, youth homeownership, rent burden, childcare, youth income/wealth, unemployment/NEET, migration, loneliness/social connection and institutional trust.

Test rather than assume the feedback:
stagnation + housing scarcity + youth insecurity → delayed households/relationships → lower fertility → aging/fiscal pressure → political/social strain.

Also model counterforces:
automation, labor-scarcity wages, immigration, housing construction, family policy, AI productivity, inheritance and cheaper services.
