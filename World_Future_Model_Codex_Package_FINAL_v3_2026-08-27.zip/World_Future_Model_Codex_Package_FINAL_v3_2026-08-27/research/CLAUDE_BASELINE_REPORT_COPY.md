# Global Development, Technology, Demographics & Civilizational Trajectory Model (v1.0 — August 26, 2026)

*A technology- and development-central model of national power, economic development, and — separately — ordinary-citizen prosperity, across \~190 sovereign states, tested against the user's 16 hypotheses and the v0.1 prior. Scores are structured judgments (0–100), not measurements; treat directions and rankings as more reliable than absolute numbers. Data current to August 2026; official-statistics skepticism applied and flagged in-line.*

## TL;DR

- The scarce inputs of development are shifting from **cheap human labor toward capital, electricity, compute, institutions and engineering talent.** As a result, **national power, GDP, and median-citizen welfare are diverging almost everywhere** — most starkly in the United States (top 1% hold \~31.6% of household wealth, Q1 2026 Fed data) and in resource-rent states. A large young population is no longer an automatic asset; the operative question is "can this economy productively employ its young people?"
- The strongest v0.1 hypotheses **survive testing:** Western Europe faces genuine *relative* decline (EU electricity 2–3× US prices per Draghi); AI is already hitting India's services model (top-5 IT firms cut \~7,000 net jobs in FY26 while revenue rose); China stays industrially dominant while shrinking (7 of top-10 EV-battery makers, 54% of 2024 global robot installs, TFR \~1.0). But some need **correction**: middle-income fertility is collapsing *faster* than v0.1 assumed, while South Korea's fertility actually *rose* two years running (0.72→0.80), the single strongest piece of evidence against demographic-doom determinism.
- The societies that convert technology into *broad* prosperity are a **narrow set — high-capacity democracies with broad capital ownership and the ability to build fast** (Nordics, Netherlands, Switzerland, Singapore, Australia, Canada; Gulf converters for their nationals) — plus genuine convergers (India, Vietnam, Poland, Mexico *if* it executes on energy). The largest group (US, China, resource states) gains national power while leaving median citizens behind or dependent; the biggest at-risk group is young, fast-growing, low-capacity states where population outruns jobs.

---

# PART 1 — GLOBAL EXECUTIVE SUMMARY

**The forces reshaping the world, 2026–2050:**

1. **The input inversion.** For two centuries, abundant labor was a development asset. As AI gets cheap and robotics spreads (global robot density doubled 2014–2024; South Korea 1,220 robots per 10,000 manufacturing workers, #1 in the world), the binding constraints become **electricity, compute, capital, and state execution capacity.** This is the model's central structural claim, and the evidence supports it.
2. **A US–China AI duopoly with a collapsing quality gap.** US private AI investment hit $285.9bn in 2025 (23× China's $12.4bn), yet the top-model performance gap fell to just **2.7%** by March 2026 — Anthropic's Claude Opus 4.6 (Arena 1,503) vs ByteDance's Dola-Seed-2.0-Preview (1,464), down from 17.5–31.6 percentage points in May 2023 (Stanford HAI 2026 AI Index). Chinese open-weight models (DeepSeek, Alibaba Qwen) rose from \~1.2% of global usage in late 2024 to \~30% in 2025 — meaning developing countries can now access near-frontier intelligence cheaply. This is a genuine leapfrog channel.
3. **Compute and electricity as the new oil.** US data-center power demand is forecast to rise from 31 GW (2025) to 66 GW (2027) per Goldman Sachs; global data-centre electricity is projected to **more than double to \~945 TWh by 2030 (\~3% of global demand), reaching \~1,200 TWh only by 2035** (IEA "Energy and AI," April 2025). The ability to *build generation fast* becomes a core national-power variable — favoring the US, China, and the Gulf, penalizing Europe.
4. **Manufacturing automates and concentrates in China.** China holds \~2 million industrial robots (world's largest stock, \~4.5× Japan), installed 54% of the world's new robots in 2024, and holds 7 of the top-10 EV-battery makers (72.6% share, Jan–May 2026). Robotics erodes the cheap-labor development ladder from the top down.
5. **Global fertility has crossed a threshold.** 131 of 237 countries/areas (55%) were below replacement in 2024, **accounting for 68% of the total global population** (UN World Fertility 2024); projected 174 (73%) by 2054. This is now a middle-income phenomenon, not a rich-world one.
6. **Aging + productivity is the real demographic question,** not raw age structure. Aging + high automation (Japan, Korea) is manageable; aging + low productivity (Southern Europe, Russia) is dangerous.
7. **Wealth concentration co-moves with AI.** US top-1% wealth share ≈31.6% (Q1 2026 Fed Distributional Financial Accounts); the top 1% could hypothetically buy 99% of US homes (Redfin). *Who owns the machines* determines whether AI productivity is broadly shared or captured by capital.
8. **The country/citizen split widens** — the report's organizing distinction.
9. **Supply-chain diversification ("China+1") creates hinge economies** — Mexico ($40.87bn record FDI 2025), Vietnam ($38.4bn registered FDI 2025), Poland, Morocco, India.
10. **AI threatens service-export models.** India's IT majors cut headcount in FY26 for the first time in years as AI automates billable hours.
11. **Energy geopolitics turned kinetic.** The 2026 Iran war closed the Strait of Hormuz — which carries \~20 million b/d, roughly 25% of the world's maritime oil trade (nearly 34% of global crude trade in 2025 per IEA) — reshaping Gulf economics and global energy risk.
12. **State capacity beats regime type,** though democracy's error-correction adds resilience (IMF, Imam & Temple).
13. **Regulatory friction is a growth tax in the West.** Europe's inability to build energy, housing, and data centers fast is now a first-order competitiveness problem (Draghi).
14. **Brain drain is a fiscal transfer from poor to rich.** \~89,000 doctors and \~257,000 nurses in OECD countries originate from the most vulnerable health systems (WHO Support & Safeguards List; OECD International Migration Outlook 2025).
15. **Social-cohesion strain is measurable** in youth housing exclusion, delayed household formation, and wealth concentration — but does *not* mechanically cause political collapse.

---

# PART 2 — GLOBAL COUNTRY SCOREBOARD

Scores 0–100 (higher = stronger position as of 2026). Column order: **NatPow / EconDev / TechAdapt / TechOwn / Mfg / StateCap / RegEff / HumCap / Energy / Capital / Demog / LaborAbsorp / BrainGain / ResourceVal / ResourceDist / Housing / Stability / MedianCitizenProsperity** → 2030/2040/2050 direction. Small-state scores are indicative and low-confidence.

### North America

- **United States** — 96/88/97/98/72/78/70/88/90/95/62/74/90/78/55/45/60/70 → ↑↑ / ↑↑ / ↑ (nation rises; median citizen lags on housing/health/capital ownership)
- **Canada** — 68/64/78/58/50/80/62/86/82/78/58/66/85/80/70/38/78/74 → → / ↑ / ↑ (housing crisis is the key drag)
- **Mexico** — 58/72/52/38/64/48/50/58/60/55/60/58/40/62/45/55/50/60 → ↑↑ / ↑ / ↑ (manufacturing hinge; security/energy/rule-of-law risks)

### Central America / Caribbean

- **Panama** — 40/62/48/30/28/58/55/58/55/60/58/55/45/40/50/50/60/62 → ↑ / ↑ / → (logistics/finance hub)
- **Costa Rica** — 34/60/56/32/40/62/58/70/68/52/54/58/50/35/55/48/72/66 → ↑ / ↑ / ↑ (high-value FDI, medical devices)
- **Dominican Republic** — 32/58/40/24/34/44/46/50/48/44/56/52/38/34/44/46/56/56 → ↑ / ↑ / →
- **Guatemala / Honduras / El Salvador / Nicaragua** — \~24/44/30/18/28/32/36/38/42/34/62/40/28/30/34/40/38/44 → → (remittance-dependent: El Salvador \~24% GDP, Honduras \~27%, Nicaragua 27.2%; emigration pressure)
- **Cuba** — 22/24/26/14/22/30/24/62/34/18/44/34/22/28/30/30/34/32 → ↓ / ↓ / → (state failure, mass emigration)
- **Haiti** — 6/12/10/4/8/6/10/22/16/8/58/16/8/12/10/18/8/16 → ↓↓ / ↓ / ↓ (fragile state)
- **Jamaica / Trinidad / smaller Caribbean** — \~28/46/38/20/24/46/48/52/46/42/40/44/30/38/40/48/54/52 → → / → / ↓ (UN flags Jamaica births could roughly halve 2024–54)

### South America

- **Brazil** — 62/58/56/40/52/50/48/60/78/58/54/54/58/76/50/52/54/56 → ↑ / ↑ / → (energy/ag/mineral strength; chronic productivity weakness)
- **Chile** — 44/62/58/40/40/66/62/64/70/60/52/58/56/82/68/50/64/64 → ↑ / ↑ / ↑ (lithium/copper + institutions)
- **Argentina** — 46/54/54/34/48/40/38/68/72/40/56/50/44/70/44/48/44/50 → high-variance ↑↑ or ↓ (Milei reform volatility)
- **Colombia** — 40/52/48/28/40/44/44/54/58/48/58/50/40/56/44/48/44/52 → → / ↑ / →
- **Peru** — 34/50/40/22/32/38/42/48/54/46/56/48/38/70/40/44/42/48 → → (copper; political instability)
- **Uruguay** — 30/58/56/34/34/70/64/66/62/54/48/56/54/44/60/52/74/68 → ↑ / ↑ / ↑ (high-capacity small state)
- **Venezuela** — 18/20/18/8/16/14/16/40/58/16/48/28/14/78/12/30/22/24 → ↑ (from collapse)
- **Guyana** — 40/80/30/20/16/34/38/40/78/50/56/40/24/92/28/42/48/58 → ↑↑ / ↑ / → (oil boom; classic rentier test; \~54% of physicians historically emigrated)
- **Bolivia / Paraguay / Ecuador** — Bolivia lithium-rich, weak institutions; Paraguay hydro/agri; Ecuador oil + insecurity

### Western Europe

- **Germany** — 74/56/64/58/82/74/54/82/44/76/44/58/72/34/60/58/72/76 → ↓ / ↓ / → (China exposure, energy, aging)
- **France** — 70/58/66/56/60/68/50/78/72/70/52/54/70/34/62/54/60/74 → → / → / → (fiscal/political execution risk; nuclear strength)
- **Netherlands** — 60/68/78/64/62/82/64/84/56/80/50/64/80/34/64/48/76/80 → ↑ / ↑ / ↑ (ASML; high-capacity)
- **Belgium** — 44/58/66/48/54/66/52/78/50/68/50/56/70/30/58/50/64/74 → →
- **Ireland** — 40/76/72/48/56/72/68/84/60/74/54/62/74/30/60/44/70/78 → ↑ / ↑ / ↑ (FDI/pharma; distorted GDP)
- **Austria / Luxembourg** — \~44/64/68/50/56/74/58/80/54/78/48/58/72/30/62/50/72/78 → →

### Northern Europe (Nordics)

- **Sweden** — 52/66/80/68/66/84/66/86/70/78/54/62/78/48/72/50/78/82 → ↑ / ↑ / ↑
- **Denmark** — 48/68/82/64/60/86/70/86/68/76/52/64/80/44/74/52/82/84 → ↑ / ↑ / ↑ (Novo Nordisk; top-5 robot density)
- **Norway** — 46/72/74/58/48/88/68/84/94/92/56/64/80/94/90/54/84/88 → ↑ / ↑ / ↑ (resource-to-capital exemplar; sovereign fund >$1.8T)
- **Finland** — 42/60/74/54/56/84/66/84/66/70/50/58/74/50/70/50/80/80 → → / ↑ / ↑
- **Iceland** — 24/60/70/40/30/80/64/78/96/60/56/56/70/60/76/48/82/80 → ↑

### Southern Europe

- **Italy** — 60/46/52/44/68/52/40/64/46/62/34/44/50/28/54/54/54/64 → ↓ / ↓ / ↓ (productivity/aging; \~70% of 18–34s live with parents)
- **Spain** — 54/54/56/42/50/56/46/68/62/58/44/40/54/30/54/46/58/62 → → / ↑ / → (youth jobs, TFR \~1.12, housing trap; 2025 growth 2.9%)
- **Portugal** — 34/52/56/38/40/58/50/64/64/52/42/46/52/30/56/44/64/62 → → / ↑ / → (brain drain + emigration)
- **Greece** — 30/44/46/32/34/46/40/62/56/42/36/38/40/30/48/48/48/54 → → / → / ↓
- **Malta / Cyprus** — \~24/56/56/34/26/56/54/62/50/56/44/50/50/28/48/44/62/62 → →

### Central / Eastern Europe

- **Poland** — 56/68/58/40/64/64/56/72/54/58/48/60/50/44/56/50/62/68 → ↑↑ / ↑ / → (catch-up + manufacturing; runs out of young workers)
- **Czechia** — 40/64/60/42/70/66/58/74/52/58/46/60/56/34/58/50/68/72 → ↑ / ↑ / → (deep industrial supplier base)
- **Romania** — 36/60/52/32/48/48/48/60/56/48/44/54/38/44/50/50/54/58 → ↑ / ↑ / → (brain drain)
- **Hungary** — 34/56/52/34/60/54/50/64/50/50/44/56/48/32/52/48/52/60 → → (EV/battery FDI hub)
- **Slovakia / Slovenia / Croatia / Bulgaria / Baltics** — Slovenia robot density 315 (top-10); Estonia digital-government leader (\~44/62/70/44/52/70/62/74/54/54/46/56/52/30/54/48/66/68) → ↑; Bulgaria/Baltics face steep depopulation

### Russia / Belarus / Ukraine

- **Russia** — 66/38/40/28/44/54/34/70/86/40/38/48/30/90/38/46/40/44 → ↓ / ↓ / ↓ (isolation, demography, brain drain; wartime power props short-term)
- **Ukraine** — 24/34/40/20/38/40/34/64/44/24/34/38/22/56/38/38/26/34 → war-outcome-dependent; reconstruction upside
- **Belarus** — 22/34/32/16/38/44/28/60/48/26/40/42/24/40/34/40/28/38 → ↓ / →

### Middle East (non-Gulf)

- **Israel** — 62/72/90/78/54/70/60/86/58/78/64/64/72/30/54/48/48/76 → ↑ / ↑ / ↑ (frontier tech; TFR \~2.9; geopolitical/internal-cohesion risk)
- **Turkey** — 54/56/50/34/60/52/40/62/54/44/54/50/38/44/48/46/42/52 → ↑ / ↑ / → (macro/institutions volatile)
- **Iran** — 44/30/40/22/44/44/28/66/76/28/50/38/24/88/32/40/28/32 → ↓↓ / → / → (war, sanctions, Feb 2026 leadership decapitation)
- **Iraq** — 30/34/26/12/24/28/22/44/82/30/58/34/20/86/24/34/28/34 → → (oil-rent trap)
- **Jordan / Lebanon / Syria / Yemen** — Lebanon collapsed (remittances \~28% GDP); Jordan stable-fragile; Syria/Yemen fragile (6–20 range)

### Gulf States

- **UAE** — 62/78/80/58/44/82/74/70/88/90/62/66/78/86/78/56/72/80 → ↑↑ / ↑ / ↑ (resource-to-capital + AI; immigration-based population)
- **Saudi Arabia** — 60/64/62/44/40/64/58/58/90/82/64/54/58/92/70/52/60/62 → ↑ / ↑ / → (Vision 2030; PIF \~$1.2T; execution/fiscal risk)
- **Qatar** — 48/72/64/42/30/72/66/62/92/88/60/58/72/90/80/54/68/78 → ↑
- **Kuwait / Bahrain / Oman** — Bahrain non-oil share \~85%; Oman Vision 2040 executing; Kuwait rentier-stagnant

### North Africa

- **Morocco** — 40/60/48/26/50/56/50/50/58/48/54/50/36/46/48/48/56/54 → ↑↑ / ↑ / → (nearshore auto/EV; renewables; Tangier port)
- **Egypt** — 44/44/38/20/40/40/32/48/58/34/56/40/28/50/34/40/40/40 → → / ↑ / → (debt/jobs/state-dominated economy)
- **Algeria** — 34/34/28/14/28/34/26/50/78/34/50/36/24/82/30/38/34/36 → → (hydrocarbon dependence)
- **Tunisia / Libya** — Tunisia brain drain + fiscal stress; Libya fragmented rentier

### Sub-Saharan Africa

- **Nigeria** — 42/44/36/16/28/28/28/40/44/30/70/34/24/72/28/34/30/34 → ↑↑ (national) / ↓ (per-capita) — labor entrants peak 3.4M/yr by 2030
- **South Africa** — 46/40/48/28/46/44/42/54/48/58/44/24/46/76/44/44/34/40 → ↓ unless reform (unemployment 33.6%, youth 15–34 at 47.4%, Q2 2026)
- **Kenya** — 34/52/48/22/28/42/44/50/54/40/64/44/32/40/40/42/46/46 → ↑ (digital leapfrog: M-Pesa; low AI-readiness tier)
- **Ethiopia** — 30/46/28/12/30/38/30/38/62/28/66/36/24/44/34/38/34/34 → ↑ (national) / → (median) — GERD hydro; stability risk
- **DRC** — 24/40/16/6/10/16/14/30/40/18/72/22/12/96/14/24/22/22 → ↑ (resource GDP) / ↓ (median) — cobalt/copper capture archetype
- **Ghana / Senegal / Côte d'Ivoire / Tanzania / Uganda / Rwanda / Angola / Botswana / Zambia / Mozambique / Zimbabwe** — Rwanda high-capacity small state (weak feedback); Botswana diamonds + institutions; Angola oil-rentier; Senegal new oil/gas; Mozambique LNG; Zimbabwe distressed
- **Sahel (Mali, Niger, Burkina Faso, Chad) / Somalia / South Sudan / CAR** — fragile, coup-belt, TFR near 6, 6–24 range

### South Asia

- **India** — 76/80/68/48/54/52/44/58/56/66/62/48/56/56/44/46/52/56 → ↑↑ / ↑↑ / ↑ (convergence superpower; AI-services threat; TFR 1.9)
- **Pakistan** — 38/34/32/14/34/30/26/34/44/26/64/30/20/40/28/32/28/30 → ↓ / high-upside — jobs/governance/energy
- **Bangladesh** — 34/48/34/16/42/38/34/40/44/32/58/44/24/32/36/40/42/42 → mixed (robots vs apparel; crossed below replacement \~2026)
- **Sri Lanka / Nepal / Afghanistan** — Nepal remittances \~25% GDP; Sri Lanka post-crisis recovery; Afghanistan fragile

### Central Asia

- **Kazakhstan** — 42/54/44/26/34/48/44/60/76/48/54/50/38/82/46/48/48/52 → ↑ (resource diversification; Middle Corridor transit)
- **Uzbekistan** — 34/52/38/20/34/44/40/52/58/38/60/46/32/56/42/44/46/46 → ↑ (reform; rare fertility uptick)
- **Tajikistan / Turkmenistan / Kyrgyzstan** — Tajikistan world's most remittance-dependent (\~45% GDP); Turkmenistan gas-rentier

### China / Greater China

- **China** — 92/78/88/82/94/82/60/74/88/82/38/62/64/58/52/56/64/62 → ↑↑ / ↑ / ↑ (industrial superpower; demographics ↓↓; TFR \~1.0)
- **Taiwan** — 58/74/88/80/86/74/64/82/54/72/40/62/70/30/58/48/54/76 → ↑ (semiconductors; China risk; robot density 302)
- **Hong Kong** — 40/62/70/50/30/66/62/74/48/82/40/56/64/28/58/40/48/70 → ↓ / →

### Japan / Korea

- **Japan** — 78/62/82/76/84/80/58/84/56/78/34/64/74/32/62/58/78/82 → ↓ relative / → living standard (robots offset aging)
- **South Korea** — 66/68/90/80/86/78/62/86/58/74/32/62/70/30/58/44/58/78 → ↑ / → / → (robot density 1,220 #1; fertility 0.80, up from 0.72 — fragile rebound)

### Southeast Asia

- **Singapore** — 62/82/88/64/58/92/82/82/60/92/40/66/88/28/64/40/78/84 → ↑ (high-capacity small state; robot density 730+; immigration offsets ultra-low fertility)
- **Vietnam** — 48/70/54/28/62/56/50/56/54/48/48/58/40/46/44/46/54/56 → ↑↑ / ↑ / → (star manufacturing hinge; aging window opening)
- **Malaysia** — 46/64/60/34/64/58/56/62/62/56/50/58/48/58/50/50/58/62 → ↑ (semiconductor packaging; medium AI-readiness)
- **Indonesia** — 54/62/46/26/50/48/42/48/56/48/56/52/36/70/42/46/50/50 → ↑ (nickel downstreaming; skills/governance)
- **Thailand** — 44/54/52/32/62/52/48/56/56/54/40/54/44/44/48/48/46/56 → → (aging before rich; Chinese EV competition)
- **Philippines** — 38/54/44/22/34/42/40/50/46/40/60/44/30/36/38/42/44/46 → mixed (AI vs BPO; \~$40bn remittances)
- **Myanmar / Cambodia / Laos** — Myanmar civil war/fragile; Cambodia cheap-labor model threatened; Laos debt-distressed

### Oceania

- **Australia** — 60/64/66/44/38/80/62/82/86/78/58/62/86/88/76/40/78/78 → ↑ (resources + housing crisis)
- **New Zealand** — 38/58/62/38/32/78/64/78/72/64/54/58/78/64/72/42/78/74 → → / ↑
- **Pacific Islands (Fiji, PNG, Tonga, Samoa, etc.)** — climate-exposed; Tonga/Samoa remittance-dependent (\~26–38% GDP); PNG resource-rich/low-capacity

*Micro-states (Andorra, Monaco, San Marino, Liechtenstein, Brunei, Maldives, Bhutan, Seychelles, Mauritius, Cape Verde, small Pacific/Caribbean states) follow their archetype: financial/tourism micro-hubs score high on capital/stability and low on scale; resource micro-states (Brunei) are rentier; climate-exposed atolls face existential downside. Mauritius and Cape Verde are relative African governance bright spots.*

---

# PART 3 — REGIONAL FUTURES

**NORTH AMERICA.** The strongest macro-region: US AI/capital dominance, Mexican manufacturing, Canadian resources. Advantages: deepest capital markets, energy abundance, USMCA integration, frontier tech. Weaknesses: US inequality/housing/health cost structure; Mexican rule-of-law erosion (2025 judicial reform), security, and energy/water bottlenecks; Canadian productivity and housing. Demographics: aging but immigration-buffered (US/Canada); Mexico near replacement (crossed \~2016). Winners: US capital owners, Mexican northern/Bajío states. Losers: US non-college workers exposed to *both* AI and housing costs. Surprise upside: Mexico if the July 2026 USMCA review locks in rules-of-origin clarity. Surprise downside: Mexico if tariff volatility + security deter realized FDI.

**CENTRAL AMERICA / CARIBBEAN.** Remittance-dependent, climate-exposed, emigration-bleeding. Panama (logistics/finance) and Costa Rica (high-value FDI, medical devices) stand out; Haiti is a collapsed state. Median-citizen outlook: stagnant-to-improving where remittances and tourism hold.

**SOUTH AMERICA.** Resource-rich, institutionally uneven. Chile (lithium/copper + institutions) and Uruguay (governance) are the converters; Argentina is the highest-variance major economy on Earth; Brazil has energy/agri/mineral depth but chronic productivity weakness; Guyana is the textbook new-oil rentier test. Fertility already below replacement (Brazil since 2002).

**WESTERN EUROPE.** The core of the v0.1 "relative decline" thesis — broadly confirmed. Advantages: high living standards, strong institutions, world-class niches (ASML, Novo Nordisk, aerospace, luxury). Weaknesses: electricity 2–3× US prices (Draghi), heavy digital-tech import dependence, weak frontier-tech formation, regulatory friction, aging. Median citizen stays rich but relatively stagnant. Winners: Netherlands, Ireland, high-capacity niches. Losers: broad manufacturing exposed to Chinese competition + energy costs (Germany). Surprise upside: German fiscal expansion (2026 growth revised up to \~0.9%). Surprise downside: French fiscal/political paralysis.

**NORTHERN EUROPE.** The model's median-citizen champions. Nordics + Netherlands combine high state capacity, broad capital ownership (pensions, Norway's sovereign fund), buildable-enough housing, and strong human capital. Norway is the resource-to-capital exemplar; Denmark/Sweden have top-10 robot density. This region best *breaks* the "Western decline" cycle.

**SOUTHERN EUROPE.** The clearest social-reproduction stress case: Italy (\~70% of 18–34s at home, TFR \~1.2), Spain (TFR \~1.12, half of 25–29s with parents), Greece. Housing trap → delayed household formation → low fertility → shrinking labor force. Spain's 2025 growth (2.9%) outperforms but doesn't fix youth formation.

**CENTRAL/EASTERN EUROPE.** Getting the factories (EV/battery FDI, China+1) exactly as it runs out of young workers — the v0.1 paradox, confirmed. Poland is the star converger; Czechia has genuine industrial depth; Romania/Bulgaria/Baltics face steep depopulation and brain drain westward.

**RUSSIA / BELARUS / UKRAINE.** Russia: relative decline locked in — isolation, brain drain, demographic contraction, resource-rent dependence — though high energy/resource value and wartime mobilization prop up national power short-term. Ukraine: trajectory-dependent on war outcome; reconstruction is the upside.

**MIDDLE EAST (non-Gulf).** Dominated in 2026 by the Iran war (Feb 28 US–Israeli strikes killed Supreme Leader Khamenei; the Hormuz crisis). Israel is a frontier-tech power with acute geopolitical and internal-cohesion risk. Turkey has manufacturing scale but macro/institutional volatility. Iran faces severe downside.

**GULF STATES.** The resource-to-capital converters, testing whether sovereign-wealth-led diversification works. UAE leads; Saudi Vision 2030 shows real non-oil progress (\~50–55% non-oil GDP) but execution/fiscal risk; Qatar/Bahrain/Oman diversifying. Median-citizen benefit is high for nationals, structurally excluded for migrant-labor majorities.

**NORTH AFRICA.** Morocco is the bright spot (nearshore auto/EV, renewables). Egypt is debt-and-jobs constrained with a state-dominated economy. Algeria/Libya are hydrocarbon-dependent.

**SUB-SAHARAN AFRICA (West/Central/East/Southern).** The demographic epicenter: working-age population grows 620M+ by 2050, needing \~25M jobs/year (World Bank, Oct 2025). The binary is stark — digital/energy leapfrog (Kenya's mobile money) vs. employment crisis (only \~100M jobs projected against 450M new workers by 2035). Nigeria, Ethiopia, DRC embody "national GDP up / per-capita and median down." Fragile states (Sahel, Somalia, South Sudan) are the downside cluster.

**SOUTH ASIA.** India is the convergence superpower (highest large-economy growth, \~6.3% FY26 per IMF) facing the AI-services threat and jobs/infrastructure constraints. Pakistan and Bangladesh face the demographic-pressure + cheap-labor-threat combination.

**CENTRAL ASIA.** Kazakhstan (resource diversification, trade corridors) and reforming Uzbekistan lead; landlocked geography constrains, but Middle Corridor China–Europe transit is an upside.

**CHINA / GREATER CHINA.** Industrial superpower consolidating (robotics, EVs, batteries, closing AI gap) while demographics deteriorate sharply (TFR \~1.0, shrinking workforce). Taiwan is the semiconductor linchpin with existential China risk.

**JAPAN / KOREA.** Aging technological powers — the "old but highly automated" test. Both lead in robot density, keep high living standards, and lose relative geopolitical weight. Korea's fertility uptick (0.72→0.80) is a rare positive signal.

**SOUTHEAST ASIA.** The prime China+1 beneficiary region. Vietnam is the hinge star (aging and skill constraints loom); Singapore is the high-capacity hub; Malaysia climbs the semiconductor value chain; Indonesia downstreams nickel; Thailand ages before it gets rich; the Philippines faces the AI-vs-BPO question.

**AUSTRALIA / NZ / PACIFIC.** Resource wealth + strong institutions + acute housing unaffordability (Australia/NZ); Pacific micro-states are climate-existential and remittance-dependent.

---

# PART 4 — DEEP COUNTRY PROFILES (38 countries)

### UNITED STATES

**Current position:** The single strongest national actor — frontier AI, deepest capital markets, energy abundance, reserve currency. **Why win:** Owns the AI stack; US private AI investment $285.9bn in 2025 (California alone $218bn); data-center-led capex drove over a third of H1-2025 GDP growth. **Why lose:** Gains captured by capital — top-1% wealth \~31.6% (Q1 2026); housing/health/education costs crush median household formation. **Demographics:** Aging, immigration-buffered; TFR \~1.6. **Marriage/fertility/household:** <25% of 25–34s hit all four adulthood milestones (out of home, married, working, kids) vs \~half in 1975; married-couple households 47% (2022) vs 71% (1970). **Youth employment:** Solid but entry-level softening as AI hits graduate hiring. **Migration:** Historic brain-gain magnet, but AI researchers moving *to* the US fell \~80% in the last year (Stanford) — a warning sign. **AI:** Frontier leader. **Robotics:** Density 307 (top-10) but below Asian leaders. **Manufacturing:** Reshoring wave but shallow supplier base vs China. **Energy:** Abundant gas + growing solar; grid buildout is binding (31→66 GW data-center demand 2025–27). **Capital:** Unmatched. **State capacity:** High federal tech capacity; slow permitting/building. **Housing:** Severely unaffordable; top 1% could buy 99% of homes. **Inequality:** Extreme, rising. **US/China:** The defining rivalry. **Median outlook:** ↑ for asset owners, →/? for renters/non-college. **2030** ↑↑ nation / → median; **2040** ↑↑ / ↑?; **2050** ↑ / ↑?. **Bull (35%):** AI productivity broadens + housing/health reform. **Base (50%):** Nation dominant, median stagnation persists. **Bear (15%):** AI-capex correction + political instability. **Watch:** AI capex ROI, housing starts, median real wages, wealth-share trend.

### CHINA

**Current position:** Industrial superpower closing the AI gap, demographically declining. **Why win:** \~2M industrial robots (largest stock), 54% of 2024 global installs; 7 of top-10 EV-battery makers (72.6% share); Chinese open-weight AI \~30% of global usage; fastest generation buildout. **Why lose:** TFR \~1.0, shrinking workforce, youth unemployment 17.9% (July 2026, ex-students); property bust (real-estate investment −19.2% in first 7 months of 2026); low household-consumption share; weak feedback. **Marriage/fertility:** Marriages rose post-COVID (echo); births 9.54M in 2024 (+5.8%). **Youth employment:** Structural graduate glut (12.7M grads 2026). **State capacity:** Very high execution, weak error-correction (IMF autocracy-vulnerability caution applies). **Median outlook:** ↑ but capped by low consumption share + aging. **2030** ↑↑ / ↑; **2040** ↑ / ↑; **2050** ↑ / → (demographic drag). **Bull (30%):** Tech self-sufficiency + consumption rebalancing. **Base (50%):** Industrial dominance, demographic drag mounts. **Bear (20%):** Property/debt + policy-error spiral. **Watch:** births, youth unemployment, consumption share, chip self-sufficiency.

### INDIA

**Current position:** Fastest-growing large economy (\~6.3% FY26 per IMF); convergence superpower candidate. **Why win:** Scale, young workforce, digital public infrastructure (UPI/Aadhaar), rising manufacturing, English services, high AI-readiness tier. **Why lose:** AI threatens the \~$283bn IT/BPO model — top-5 firms cut \~7,000 net jobs in FY26 while revenue rose; TCS cut \~12,000+ roles (2% of workforce); infrastructure gaps; jobs deficit; low female labor participation. **Demographics:** TFR now 1.9 (below replacement) — earlier than old models assumed; still young age structure. **Migration:** World's largest remittance recipient — a record **$129.1bn in 2024, the highest-ever single-year inflow for any country, 14.3% of global remittances** (World Bank); also a top physician-export source — the remittance-benefit-vs-human-capital-loss tension in pure form. **AI:** Strong adoption + talent, weak frontier ownership. **State capacity:** Improving digitally, uneven physically; strong democratic feedback. **Median outlook:** ↑ (genuine convergence). **2030** ↑↑; **2040** ↑↑; **2050** ↑. **Bull (35%):** Manufacturing + services-up-value-chain + demographic dividend realized. **Base (45%):** Solid convergence, jobs lag population. **Bear (20%):** AI guts services before manufacturing scales. **Watch:** IT-sector headcount, manufacturing FDI, female LFP, electricity per capita.

### MEXICO

**Current position:** Prime manufacturing hinge between US and Asia. **Why win:** Record FDI $40.87bn (2025, +10.8%); manufacturing exports to US $535bn in 2025 (+$150bn since 2021); \~77% of exports USMCA-qualifying; labor \~$4.90/hr vs China \~$6.50; 2–5 day truck transit vs 25–40 days ocean. **Why lose:** Rule-of-law erosion (2025 judicial reform), security, electricity/water bottlenecks, tariff volatility (Feb 20 2026 SCOTUS struck the 25% IEEPA tariff; Section 122 10% surcharge). **Demographics:** Near replacement (crossed \~2016); "old before rich" risk — perhaps 15–25 productive years, contingent on execution. **Migration:** 2nd-largest remittance recipient (\~$68bn 2024). **Robotics:** Density only 62. **Energy:** The key bottleneck — state-dominated CFE, slow renewables permitting. **Median outlook:** ↑ if nearshoring wages broaden. **2030** ↑↑; **2040** ↑; **2050** ↑. **Bull (30%):** USMCA clarity + energy reform → deep industrialization. **Base (50%):** Steady assembly growth, governance drags. **Bear (20%):** Security/energy/tariffs choke the moment. **Watch:** July 2026 USMCA review, electricity capacity, homicide trend, realized (not announced) private investment.

### GERMANY

**Current position:** Europe's industrial anchor in relative decline. **Why win:** Deep engineering, Mittelstand, machine tools, robot density 449 (3rd), fiscal space now deployed (defense/infrastructure; 2026 growth revised up to \~0.9%). **Why lose:** Energy costs (EU electricity 2–3× US), China as both competitor (EVs) and market, aging, weak digital/tech formation. **Median outlook:** High but stagnant. **2030** ↓; **2040** ↓; **2050** → (stabilizes lower). **Bull (25%) / Base (55%) / Bear (20%).** **Watch:** electricity prices, auto-sector share, EV competitiveness.

### FRANCE

**Current position:** Diversified, nuclear-powered, politically strained. **Why win:** Cheap low-carbon nuclear electricity (a real edge vs Germany), aerospace/defense/luxury/nuclear champions, best large-EU fertility (\~1.6–1.8). **Why lose:** Fiscal deficits, political fragmentation, execution paralysis. **2030/2040/2050** → / → / →. **Bull (25%) / Base (55%) / Bear (20%).** **Watch:** fiscal path, political stability, nuclear renewal.

### UNITED KINGDOM

**Current position:** Services/finance power with weak investment and productivity. **Why win:** High AI-readiness, finance, universities, language, DeepMind heritage. **Why lose:** Chronic underinvestment, flat productivity (\~1.3% growth 2025–26), housing crisis, energy costs. **Median outlook:** Stagnant real incomes. **2030** → / ↑; **2040** →; **2050** →. **Watch:** investment/GDP, planning reform, energy costs.

### ITALY

**Current position:** Rich, aging, low-productivity, social-reproduction stress case. **Why win:** Manufacturing niches (machinery, luxury, food), household wealth. **Why lose:** \~70% of 18–34s live with parents; TFR \~1.2; debt; two decades of flat productivity; brain drain. **2030/2040/2050** ↓/↓/↓. **Median outlook:** high living standard, poor youth prospects. **Watch:** youth emigration, debt/GDP, productivity.

### SPAIN

**Current position:** Growth outperformer (2.9% 2025) with deep youth-formation problems. **Why win:** Tourism, renewables, services. **Why lose:** Housing trap (half of 25–29s with parents), TFR \~1.12, youth unemployment, low productivity. **2030** →; **2040** ↑; **2050** →. **Watch:** youth unemployment, housing construction, fertility.

### POLAND

**Current position:** Central Europe's catch-up champion. **Why win:** Manufacturing FDI, EU funds, skilled labor, Ukraine-reconstruction proximity, \~3% growth, \~12% wage growth (2025). **Why lose:** Runs out of young workers (aging + emigration legacy), coal-heavy energy transition, value-chain upgrading. **2030** ↑↑; **2040** ↑; **2050** →. **Bull (35%)/Base (50%)/Bear (15%).** **Watch:** wage/productivity gap, energy transition, labor supply.

### RUSSIA

**Current position:** Sanctioned resource-and-war economy in structural relative decline. **Why win:** Energy/resources, nuclear arsenal, wartime mobilization, food. **Why lose:** Isolation, skilled-youth exodus, demographic contraction, technological cutoff, rentier structure. **2030/2040/2050** ↓/↓/↓. **Median outlook:** declining. **Watch:** oil revenue, emigration, data reliability (high official-data skepticism).

### JAPAN

**Current position:** The premier "old but automated" test. **Why win:** Robot density 446 (4th), deep industry, robotics/materials/precision champions, high living standards, social cohesion, political stability. **Why lose:** TFR \~1.2, shrinking population, relative geopolitical decline, debt. **Median outlook:** remains high — the key counter-thesis to "aging = doom." **2030/2040/2050** ↓ relative / → living standard. **Watch:** automation-per-worker, immigration policy, real wages.

### SOUTH KOREA

**Current position:** Frontier-tech power with the world's lowest (but rising) fertility. **Why win:** Semiconductors, robotics (density 1,220, #1), batteries, shipbuilding, high AI-readiness. **Why lose:** TFR 0.80 — up from 0.72 (2023) via a marriage surge (**marriages +14.9% in 2024, the biggest jump since records began in 1970**, per Statistics Korea) and a temporary early-30s cohort bulge; extreme aging; China competition; household debt. **2030** ↑; **2040** →; **2050** → (demographic ceiling). **Watch:** whether the fertility rebound holds past the cohort effect; chip competitiveness.

### TAIWAN

**Current position:** Semiconductor linchpin (TSMC) with existential geopolitical risk. **Why win:** Dominant advanced-chip fabrication, robot density 302, engineering depth. **Why lose:** China invasion/blockade risk, TFR \~0.9, energy import dependence. **2030** ↑ (if peace); **2040/2050** trajectory-dependent. **Watch:** cross-strait tension, fab diversification abroad.

### VIETNAM

**Current position:** The star China+1 manufacturing hinge. **Why win:** Registered FDI $38.4bn (2025), realized FDI $13bn H1-2026 (5-yr high); electronics >30% of exports ($72.6bn); wages \~$3/hr; trade turnover \~$930bn. **Why lose:** Aging begins; skills gap (only \~29% of workforce formally trained); *falling* graduate wage premium; US-tariff/origin exposure; energy reliability. **2030** ↑↑; **2040** ↑; **2050** →. **Bull (35%):** Moves from assembly to design (50k semiconductor engineers by 2030 target). **Base (50%):** Solid assembly growth. **Bear (15%):** Middle-income trap + tariff shock. **Watch:** value-chain upgrading, education, energy.

### MALAYSIA

**Current position:** Semiconductor-packaging and diversified-manufacturing riser. **Why win:** Chip assembly/test hub, medium AI-readiness, decent institutions, energy. **Why lose:** Middle-income trap risk, brain drain to Singapore, political churn. **2030/2040/2050** ↑/↑/↑. **Watch:** advanced-packaging FDI, value-chain upgrading.

### INDONESIA

**Current position:** Large, young, resource-rich (nickel), governance-constrained. **Why win:** Nickel downstreaming (EV supply chain), market scale, demographic size. **Why lose:** Skills/governance gaps, low tech ownership, resource-nationalism execution risk. **2030/2040/2050** ↑/↑/↑. **Watch:** downstreaming success, education, infrastructure.

### THAILAND

**Current position:** Aging-before-rich auto-manufacturing economy. **Why win:** Auto/electronics base, tourism, some robotics. **Why lose:** TFR \~1.2 (aged early), Chinese EV competition displacing legacy auto, political instability. **2030/2040/2050** →. **Watch:** EV transition, fertility, political stability.

### PHILIPPINES

**Current position:** The AI-vs-BPO bellwether. **Why win:** Young population, English services, \~$40bn remittances, domestic demand. **Why lose:** BPO directly AI-exposed; infrastructure; low tech ownership. **2030/2040/2050** mixed / ↑ / ↑. **Watch:** BPO employment, remittances, infrastructure.

### SINGAPORE

**Current position:** The high-capacity small-state exemplar. **Why win:** State capacity (\~92), capital, robot density 730+, finance/logistics hub, high AI-readiness, immigration offsets ultra-low fertility. **Why lose:** TFR \~1.0, land/labor constraints, external-demand dependence. **Median outlook:** high. **2030/2040/2050** ↑/↑/↑. **Watch:** talent-immigration policy, hub competition.

### AUSTRALIA

**Current position:** Resource-and-services economy with a housing crisis. **Why win:** Minerals (iron ore, lithium, gas), institutions, universities, brain-gain magnet. **Why lose:** Severe housing unaffordability, low manufacturing/tech ownership, China export-dependence. **2030/2040/2050** ↑ nation, housing caps median gains. **Watch:** housing, China demand, critical-minerals value-add.

### CANADA

**Current position:** High-institution resource economy with productivity/housing problems. **Why win:** Resources, energy, education, immigration, brain-gain. **Why lose:** Weak productivity/business investment, acute housing unaffordability, US-dependence. **2030/2040/2050** → / ↑ / ↑. **Watch:** productivity, housing starts, immigration absorption.

### BRAZIL

**Current position:** Resource-and-agri giant with chronic productivity weakness. **Why win:** Agriculture, minerals, energy (hydro + oil), scale, Embraer. **Why lose:** Low productivity, fiscal fragility, inequality, crime. **2030/2040/2050** ↑/↑/→. **Watch:** productivity, fiscal path, agri-tech.

### ARGENTINA

**Current position:** The highest-variance major economy. **Why win:** Vaca Muerta shale, lithium, agriculture, human capital, Milei reforms. **Why lose:** Chronic macro instability, institutional volatility, reform-reversal risk. **2030** ↑↑ or ↓; **2040/2050** trajectory-dependent. **Bull (35%) / Base (35%) / Bear (30%).** **Watch:** inflation, reserves, reform durability.

### CHILE

**Current position:** LatAm's institutional + critical-minerals leader. **Why win:** Copper + lithium with relatively strong institutions and redistribution, solar potential. **Why lose:** Social discontent, constitutional churn, mining-permitting friction. **2030/2040/2050** ↑/↑/↑. **Watch:** lithium strategy, investment climate.

### TURKEY

**Current position:** Manufacturing scale, macro/institutional volatility. **Why win:** Diversified manufacturing (autos, defense, appliances), geography, defense-industrial rise. **Why lose:** Inflation/currency instability, institutional erosion, brain drain. **2030/2040/2050** ↑/↑/→. **Watch:** inflation, central-bank independence, FDI.

### SAUDI ARABIA

**Current position:** The flagship resource-to-capital diversification bet. **Why win:** PIF \~$1.2T AUM; non-oil GDP \~50–55% (target 65% by 2030); giga-projects; tourism (18M+ Umrah pilgrims 2025); HUMAIN AI stack; cheap energy/solar; GDP growth 4.5% (2025). **Why lose:** Oil-revenue dependence to *fund* the transition; execution/fiscal risk (giga-project costs); 2026 oil-market disruption (Iran war); labor-nationalization challenges. **State capacity:** Improving, top-down, weak feedback. **Median outlook:** ↑ for nationals. **2030** ↑; **2040** ↑; **2050** → (depends on diversification). **Bull (35%) / Base (45%) / Bear (20%).** **Watch:** non-oil GDP share, PIF returns, fiscal breakeven oil price.

### UAE

**Current position:** The Gulf's most advanced resource-to-capital converter. **Why win:** Diversified (logistics, finance, tourism), sovereign capital, AI ambition (top engineering-skill growth per Stanford), business-friendly, energy. **Why lose:** Migrant-labor-dependent (citizen minority), regional security (Iran war), oil-price exposure. **Median outlook:** high for nationals; structurally excluded for migrants. **2030/2040/2050** ↑↑/↑/↑. **Watch:** non-oil share, AI/data-center buildout, regional security.

### ISRAEL

**Current position:** Frontier-tech power under geopolitical and internal strain. **Why win:** AI (top-tier), cyber, R&D intensity, VC, defense-tech, decent fertility (\~2.9). **Why lose:** Regional war exposure, internal polarization, brain-drain risk, reservist-economy strain. **2030/2040/2050** ↑/↑/↑ (tech) but high-variance on security. **Watch:** conflict trajectory, tech-sector emigration, political cohesion.

### IRAN

**Current position:** Post-decapitation crisis state (Feb 2026 war killed Khamenei; Hormuz crisis). **Why win:** Resources (oil/gas), educated population, geographic scale. **Why lose:** War damage, sanctions, leadership vacuum, brain drain, isolation, rentier structure. **2030** ↓↓; **2040/2050** →. **Watch:** post-war political settlement, sanctions, oil exports.

### EGYPT

**Current position:** Large, young, debt-and-jobs constrained. **Why win:** Suez Canal, demographic scale, gas, regional position. **Why lose:** Debt distress, state/military-dominated economy, jobs deficit, subsidy burden, FX crises. **2030/2040/2050** → / ↑ / →. **Watch:** debt restructuring, private-sector share, jobs.

### NIGERIA

**Current position:** Africa's demographic giant — the national-rise/per-capita-decline risk incarnate. **Why win:** Population scale, oil/gas, Nollywood/fintech, youth energy. **Why lose:** Labor entrants peak 3.4M/yr by 2030 (needs \~80M new jobs), weak state capacity, oil-rent dependence, insecurity, low per-capita trajectory. **2030** ↑↑ (national) / ↓ (per-capita); **2040/2050** same tension. **Bull (25%) / Base (50%) / Bear (25%).** **Watch:** job creation, power supply, non-oil growth, security.

### SOUTH AFRICA

**Current position:** Africa's most industrialized economy in a jobs crisis. **Why win:** Mining, financial depth, infrastructure legacy, institutions. **Why lose:** Unemployment 33.6% (Q2 2026), youth 15–34 at 47.4%, NEET (15–34) 45.6%, electricity crisis, state-capacity erosion, crime. **2030/2040/2050** ↓ unless reform. **Median outlook:** poor for the excluded majority. **Watch:** electricity (Eskom), unemployment, structural reform.

### KENYA

**Current position:** East Africa's digital-leapfrog candidate. **Why win:** Mobile money (M-Pesa) pioneer, services, regional hub, young population. **Why lose:** Low AI-readiness tier, debt, jobs deficit, corruption. **2030/2040/2050** ↑/↑/↑. **Watch:** digital-economy jobs, debt, governance.

### ETHIOPIA

**Current position:** Large, young, infrastructure-building, fragile. **Why win:** Population scale, GERD hydropower, manufacturing ambition, agriculture. **Why lose:** Conflict/stability risk, low income base, FX/debt distress, jobs deficit (labor entrants peak \~2040). **2030/2040/2050** ↑ (national) / → (median). **Watch:** stability, power/industrial parks, debt.

### DRC

**Current position:** The resource-capture archetype. **Why win:** Cobalt/copper dominance (critical to EV batteries). **Why lose:** State fragility, conflict, near-zero downstream value capture, elite/foreign rent capture, median-citizen exclusion; historically \~54%+ of physicians emigrated. **2030** ↑ (resource GDP) / ↓ (median); **2040/2050** same. **Watch:** governance, downstream processing, eastern conflict.

### PAKISTAN

**Current position:** Demographic-pressure state with governance/energy crises. **Why win:** Population scale, agriculture, some IT services, geostrategic position. **Why lose:** Chronic fiscal/FX crises, energy shortages, weak state capacity, jobs deficit, low human capital, climate exposure. **2030** ↓ / high-upside; **2040/2050** trajectory-dependent. **Watch:** IMF program, energy, exports, political stability.

### BANGLADESH

**Current position:** Apparel-export model facing robotics threat. **Why win:** Garment scale, improving human-development indicators, remittances, domestic market. **Why lose:** Cheap-labor model exposed to automation, political instability (2024 upheaval), energy, climate. **Demographics:** Crossed below replacement \~2026. **2030/2040/2050** mixed. **Watch:** apparel automation, diversification, political settlement.

---

# PART 5 — TECHNOLOGY & DEVELOPMENT MODEL

**The new development ladder is real but not universal.** Evidence supports the shift from (agriculture→cheap labor→manufacturing→services) toward **(electricity→connectivity→compute→AI→robotics→capital→engineering→market access)**. But the old ladder still works at the bottom rungs: Vietnam, Bangladesh and Ethiopia are still climbing via manufacturing. The two ladders now coexist — and the danger is that robotics kicks away the bottom rungs (cheap-labor manufacturing) *before* poor countries finish climbing them.

**AI frontier access.** The US owns the frontier; China matches on performance (gap \~2.7%) and *leads on diffusion* via open weights (\~30% of global usage). This is the single most important fact for developing countries: they can access near-frontier intelligence cheaply without owning it. **Adoption ≠ ownership** — a country running Chinese/US models everywhere gains productivity but exports the capital income.

**Compute & energy.** The binding constraint has moved from chips to *power.* US data-center demand 31→66 GW (2025–27); global >945 TWh by 2030, \~1,200 TWh by 2035 (IEA). Countries that build generation fast (US gas/solar, China all-of-the-above, Gulf solar) gain; Europe (2–3× US electricity prices) loses.

**Robotics.** Korea 1,220 / Singapore 730+ / Germany 449 / Japan 446 / Taiwan 302 / US 307 / China 166-but-rising (yet \~2M-unit stock, largest absolute). China installed 54% of 2024's new robots — where its industrial dominance compounds.

**Technology ownership (the critical distinction).**

- *Own the stack:* US, China (partly), Taiwan/Korea (chips), Netherlands (ASML).
- *Adopt without owning:* almost everyone else — India, Southeast Asia, Latin America, Africa, most of Europe.
- *Sovereign-capital ownership plays:* Gulf states buying into the AI stack (Saudi HUMAIN, UAE) — the resource→capital→compute pathway.

---

# PART 6 — DEMOGRAPHICS / FAMILY / SOCIAL COHESION

**Headline:** Low fertility is now the global norm — 131/237 countries below replacement in 2024 (68% of world population), projected 174 by 2054. Decline has spread deep into middle-income countries faster than traditional models assumed (Thailand, Iran, Tunisia, Algeria, China among the steepest; India 1.9; Indonesia crossing \~2025; Bangladesh \~2026). **Hypothesis 11 confirmed.**

**The social-reproduction chain (evidence-graded):**

- Housing cost → delayed household formation → delayed/lower fertility: **STRONG** (Spain, Italy, Korea). \~70% of Italian 18–34s and half of Spanish 25–29s live with parents.
- Low fertility → aging → fiscal/pension pressure → higher taxes/automation/immigration demand: **STRONG** (mechanical).
- Low marriage/household formation → loneliness → weaker community → political alienation: **WEAK-TO-MODERATE** (correlational, not causal).
- Economic stagnation → pessimism → fewer children → radicalization: **WEAK** (plausible, unproven).

**The Korea counter-signal.** Fertility *rose* two years running (0.72→0.75→0.80) on a marriage surge (+14.9% in 2024, the biggest since records began in 1970) — but demographers read this as a cohort echo (early-30s bulge) plus post-COVID catch-up, not a durable reversal. Still, it is important falsification evidence against demographic determinism: policy + cohort timing can move the number.

**Western marriage/household decline is measurable:** US married-couple households 47% (2022) vs 71% (1970); <25% of US 25–34s hit all four adulthood milestones vs \~half in 1975. Whether this becomes a *reinforcing* decline cycle is the Part 13 question.

---

# PART 7 — LABOR / YOUTH / MIGRATION

**AI-exposure classification by development model:**

- **NET DISRUPTIVE:** BPO/service exporters (Philippines, parts of India). India's top-5 IT firms cut \~7,000 net jobs in FY26 while revenue rose — the clearest real-world evidence that Hypothesis 8 is materializing.
- **MIXED:** cheap-labor manufacturing (Vietnam, Bangladesh) — robotics threat looms but hasn't hit; China (automating its own labor).
- **NET COMPLEMENTARY:** high-capital, high-skill economies that own the tools (US, Korea, Singapore, UAE) — though distribution remains the question even here.

**Youth-unemployment hotspots:** South Africa 47.4% (15–34, Q2 2026), NEET 45.6%; China 17.9% (16–24 ex-students, July 2026); Southern Europe structurally high. **The Africa mega-risk:** Sub-Saharan working-age population +620M by 2050 needs \~25M jobs/year; only \~100M jobs projected against 450M new workers by 2035.

**Brain drain as a fiscal transfer.** \~89,000 doctors and \~257,000 nurses in OECD countries originate from countries on the WHO Health Workforce Support and Safeguards List — the most vulnerable systems (OECD International Migration Outlook 2025). India/Germany/China are top doctor-origin countries; Philippines/India/Poland top nurse-origin. **Remittance benefit vs human-capital loss:** India ($129.1bn, 14.3% of global), Mexico ($68bn), China ($48bn), Philippines (\~$40bn), Pakistan (\~$33bn) are top recipients; Tajikistan (\~45% GDP), Nepal (\~25%), Nicaragua (27.2%), Honduras (\~27%), Tonga most dependent. **Verdict:** remittances stabilize consumption but do not build productive capacity — brain-drain economies often "pay to educate workers who create productivity elsewhere."

---

# PART 8 — STATE CAPACITY / REGULATION

**The IMF evidence (Imam & Temple, IMF Working Paper 2025/014, "State Capacity and Growth Regimes," 108 developing countries, 1971–2016).** High state capacity helps sustain growth and limit output collapses — but these effects are "sometimes less striking than the benefits of democracy." Growth spells are longer-lived under democracy; output collapses more likely to deepen under autocracy; autocratic stagnation can tip into outright collapse (companion paper, Imam & Temple, "Political Institutions and Output Collapses," 123 countries). **This tests Hypotheses 12–15:**

- H12 (high capacity adapts fast regardless of regime): **SUPPORTED** — capacity matters independently.
- H14 (weak authoritarian feedback amplifies mistakes): **SUPPORTED** — the autocracy-deepening-collapse finding.
- H15 (democracy + high capacity = best long-run combination): **SUPPORTED** as the model's central institutional conclusion.

**Four archetypes:**

- **HIGH CAPACITY + STRONG FEEDBACK:** Nordics, Switzerland, Netherlands, Singapore (technocratic), Taiwan, Korea, Japan, Australia, Canada — the best long-run combination.
- **HIGH CAPACITY + WEAK FEEDBACK:** China, UAE, Saudi Arabia, Rwanda, Vietnam — fast execution, error-amplification risk.
- **LOW CAPACITY + STRONG COMPETITION:** India, Brazil, South Africa, Indonesia, Mexico — messy but self-correcting.
- **LOW CAPACITY + WEAK FEEDBACK:** DRC, Pakistan, Sahel, fragile states — the danger zone.

**Regulatory friction.** The West's building problem is now a first-order growth tax: Europe cannot build energy, transmission, housing, or data centers fast (Draghi: heavy digital-tech import dependence, electricity 2–3× US). The US builds business fast but housing/transmission slowly. The optimal frontier is "well-regulated / fast" (Nordics, Singapore) — **not** deregulation per se. The model rejects "less regulation = better."

---

# PART 9 — INDUSTRY / ENERGY / RESOURCES

**Industrial depth (deep ecosystem vs assembly):**

- *Deep ecosystems:* China (deepest), Germany, Japan, Korea, US, Taiwan, Italy (niches), Czechia.
- *Rising/mid-depth:* Poland, Mexico, India, Vietnam (upgrading), Malaysia, Turkey, Thailand.
- *Assembly economies:* newer Southeast Asian entrants, Morocco, Bangladesh.

**Energy position.** Best — Gulf (cheap solar+gas), US (gas+solar+nuclear restart), China (all-of-the-above), France (nuclear), Norway (hydro). Worst — Europe broadly (price), import-dependent Asia (Japan/Korea/Taiwan on security), South Africa (grid collapse), Pakistan.

**Resource rent capture vs median benefit:**

- *Converters (high capture + high median benefit):* Norway (sovereign-fund exemplar), UAE, Qatar, Chile, Botswana, Australia.
- *Rentier traps (high capture, low median benefit):* DRC, Angola, Iraq, Nigeria, Algeria, Equatorial Guinea, Turkmenistan; Guyana is the live test.
- The distinction is institutional — confirming the "resource boom + strong/weak institutions" interaction (Hypothesis 10).

---

# PART 10 — COUNTRY VS CITIZEN OUTCOMES

| Country National Power GDP Median Citizen Capital Owners  |               |    |                              |                                     |
| --------------------------------------------------------- | ------------- | -- | ---------------------------- | ----------------------------------- |
| USA                                                       | ↑↑            | ↑↑ | →/↑?                         | ↑↑↑                                 |
| China                                                     | ↑↑            | ↑  | ↑                            | ↑↑ (state+private)                  |
| India                                                     | ↑↑            | ↑↑ | ↑                            | ↑↑                                  |
| Norway                                                    | ↑             | ↑  | ↑                            | ↑ (broadly held via sovereign fund) |
| Saudi/UAE                                                 | ↑             | ↑  | ↑ (nationals) / → (migrants) | ↑↑ (state)                          |
| Germany/Italy                                             | ↓             | →  | → (high level)               | →                                   |
| Japan                                                     | ↓ (relative)  | →  | → (high level)               | →                                   |
| Mexico                                                    | ↑↑            | ↑  | ↑?                           | ↑↑ (often foreign)                  |
| DRC                                                       | ↑ (resource)  | ↑  | ↓/?                          | ↑↑ (elite/foreign)                  |
| Nigeria                                                   | ↑↑ (national) | ↑  | ↓ (per-capita)               | ↑                                   |
| South Africa                                              | ↓             | →  | ↓ (excluded majority)        | →                                   |

**Central finding:** GDP growth is an increasingly poor proxy for median welfare. The US pattern (nation ↑↑, median →/?, capital ↑↑↑) and the resource-rentier pattern (GDP ↑↑, median →/↓) are the two dominant divergence forms. The societies that keep all four columns aligned are high-capacity states with broad capital ownership (Nordics, Norway's fund, high-homeownership/high-pension systems) — the model's prescriptive core.

---

# PART 11 — 2030 / 2040 / 2050 RANKINGS

- **Most powerful (2050):** 1 USA, 2 China, 3 India, 4 EU-as-bloc, 5 Japan, 6 Russia (declining), 7 Germany, 8 UK/France, 9 Saudi/Gulf-bloc, 10 Brazil/Indonesia (rising).
- **Fastest relative risers:** India, Vietnam, Indonesia, Mexico, Poland, Morocco, UAE, Saudi Arabia, Bangladesh, Ethiopia (national), Uzbekistan.
- **Biggest relative decliners:** Russia, Italy, Greece, Germany (relative), Japan (relative geopolitical weight), South Africa (unless reform), non-oil Middle East.
- **Best technology adapters:** US, China, Korea, Singapore, Israel, Taiwan, UAE, Netherlands, Nordics.
- **Most AI-exposed economies:** Philippines, India (services), other English-language BPO exporters.
- **Biggest robotics beneficiaries:** China, Korea, Japan, Germany, Singapore, US.
- **Best manufacturing position:** China, US, Germany, Japan, Korea, Mexico, Vietnam, Poland, India.
- **Best energy position:** Gulf states, US, China, Norway, France, Australia.
- **Best demographic position (large economies):** India, Indonesia, Nigeria (if jobs), US (immigration-buffered), Israel.
- **Worst demographic position:** Korea, China, Japan, Italy, Spain, Taiwan, Eastern Europe, Russia.
- **Worst youth-employment risk:** South Africa, Nigeria, Sahel, Egypt, Pakistan, China (graduates), Southern Europe.
- **Biggest brain drain:** DRC, Sub-Saharan Africa broadly, Philippines (health), India (physicians), Eastern/Southern Europe, Central America, Russia (post-2022).
- **Biggest brain gain:** US (weakening), UAE, Australia, Canada, Switzerland, Singapore, Gulf states.
- **Best state capacity:** Singapore, Nordics, Switzerland, Germany/Netherlands, Japan, Korea, Taiwan, UAE, China (execution).
- **Most over-regulated/stagnant:** EU broadly (building/energy), Italy, France (labor/fiscal).
- **Most under-regulated/chaotic:** fragile states, parts of Latin America and Africa on rule-of-law/safety.
- **Best resource converters:** Norway, UAE, Qatar, Chile, Botswana, Australia.
- **Worst resource-rent traps:** DRC, Angola, Iraq, Nigeria, Algeria, Turkmenistan, Equatorial Guinea.
- **Best for median citizens (2050):** Nordics, Switzerland, Netherlands, Singapore, Australia, Canada, Denmark/Norway; among convergers, India and Vietnam offer the biggest *improvements* from low bases.
- **Richer-while-ordinary-people-stagnate:** USA (distribution), Gulf/resource states (excluded populations), DRC/Nigeria/Angola, China (consumption-share cap).
- **Highest political/social-strain risk:** Sahel, fragile states, South Africa, Pakistan, Egypt; among developed states, watch the US, France, and Southern Europe for intergenerational-inequality-driven strain.

---

# PART 12 — GLOBAL SCENARIOS (rough probabilities)

1. **AI Abundance / Broad Diffusion (15%):** Productivity broadens; open-weight AI + cheap energy lift developing countries. Winners: India, Southeast Asia, Africa (leapfrog), median citizens everywhere. Losers: rentiers.
2. **Techno-Rentier Capitalism (30% — the modal path):** AI productivity captured by capital owners; GDP-median divergence widens. Winners: US/China capital owners, Gulf sovereign capital. Losers: median workers in advanced economies, AI-exposed service exporters.
3. **China-Centered Industrial World (10%):** Chinese manufacturing + open-weight AI + BRI dominance. Winners: China, supply-chain partners. Losers: Western industry.
4. **US-Led AI/Capital World (20%):** US frontier + capital dominance persists. Winners: US, allies on its stack. Losers: those cut off.
5. **Multipolar Technology Blocs (25% — overlaps #2/#4):** US and Chinese tech spheres bifurcate. Winners: hedgers (India, Gulf, ASEAN). Losers: the squeezed-in-between.
6. **Robotics Destroys Cheap-Labor Development (rising through period):** Winners: robot-owners (China, Korea). Losers: Bangladesh, African manufacturing aspirants.
7. **Open AI Enables Global Leapfrogging (embedded in #1):** Winners: high-human-capital poor countries (Kenya, India, Vietnam).
8. **Demographic Stagnation / Aging Crisis (high certainty for East Asia/Europe):** Winners: automation leaders (Japan, Korea). Losers: aging + low-productivity (Southern Europe, Russia, China's later period).
9. **Energy Abundance Accelerates Development (upside):** Cheap solar/nuclear + storage. Winners: Gulf, US, China, sun-rich Africa/India.
10. **Geopolitical Fragmentation / War / Trade Blocs (elevated — the 2026 Iran war already realized part of this):** Winners: energy exporters outside chokepoints, defense-industrial states. Losers: energy importers, trade-dependent economies, chokepoint-adjacent states.

---

# PART 13 — THESIS TESTING / CONTRADICTORY EVIDENCE

**H1 (Western Europe relative decline): CONFIRMED, with nuance.** For: energy costs (2–3× US), weak tech formation, aging, regulatory friction. Against: Nordics + Netherlands + Ireland break the pattern; German fiscal expansion and French nuclear are real offsets; "decline" is *relative* — Europeans remain among the world's richest and best-served. *Changes forecast:* energy-market integration + defense/infrastructure spend + capital-markets union.

**H2 (US wins nationally, many citizens don't): CONFIRMED.** For: top-1% wealth \~31.6%; top 1% could buy 99% of homes; <25% of young adults hit adulthood milestones. Against: US median real wages grew in the mid-2020s; broad 401(k)/equity ownership means *some* AI gains reach the middle; unemployment low. Not a foregone dystopia.

**H3 (China powerful while shrinking): CONFIRMED.** Industrial/robotics/AI-diffusion dominance alongside TFR \~1.0 and shrinking workforce. Against: youth unemployment (17.9%) and the property bust show strain now; demographic drag intensifies post-2035.

**H4 (India benefits but AI threatens services): CONFIRMED — already happening.** IT-sector net job cuts in FY26 are the clearest evidence. Against: the broader IT industry still grew headcount (\~5.9M); global capability centers hire; India's convergence is broad-based, not services-only.

**H5 (Mexico manufacturing hinge): CONFIRMED.** Record FDI, $535bn exports to US. Against: FDI is more "announced" than realized; energy/security/rule-of-law could choke it; tariff volatility is real.

**H6 (China+1 winners): CONFIRMED.** Vietnam/Poland/Morocco/Malaysia/Indonesia all gaining. Nuance: Vietnam's aging + falling graduate wage premium warn against extrapolation.

**H7 (robotics kills cheap-labor advantage): SUPPORTED, not yet fully realized.** Robotics is spreading fastest in *already-industrialized* economies (China, Korea); the threat to Bangladesh/Africa is prospective. Grade: moderate, rising.

**H8 (BPO hit by AI): CONFIRMED.** India IT and Philippine BPO exposure is real and materializing.

**H9 (Africa leapfrog vs employment crisis): BOTH TRUE — employment risk dominant.** Kenya/mobile-money leapfrog is real but small; the \~25M-jobs/year gap dominates the aggregate outlook.

**H10 (resource states rich without citizen benefit): CONFIRMED** (DRC, Angola, Nigeria) — but institutions can break it (Norway, Botswana, Gulf-for-nationals).

**H11 (fertility falls into middle income): STRONGLY CONFIRMED.** 131/237 below replacement; middle-income decline faster than expected.

**H12–H15 (state capacity/regime): SUPPORTED** — see Part 8. Capacity matters independently; democracy adds error-correction; democracy + high capacity is the strongest long-run combination.

**H16 (social decline consequences beyond population size): PARTIALLY SUPPORTED, cautiously graded.** Household-formation collapse is measurable; second-order political effects are plausible but not mechanically proven. **The strongest contradiction to the doom-cycle thesis is South Korea's fertility rebound (0.72→0.80)** — showing the cycle is not inevitably self-reinforcing.

**v0.1 corrections:** (a) Korea should carry a fertility-*uptick* caveat, not just "extreme problem." (b) Saudi PIF AUM is \~$1.2T (not the older \~$700–925bn figures). (c) The "old before rich" claim for Mexico is directionally right but its 15–25-year window assumes nearshoring executes — *energy* is the swing factor. (d) The proposed weighting scheme is broadly sensible; I recommend *raising* Energy/Resources from 7% toward \~10% and Finance/Capital from 5% toward \~8% (funding this by trimming Starting-productivity 10%→8% and Geography 4%→3%), given the input-inversion thesis; Technology at 14% is if anything slightly low for the 2030s (consider 15–16%). (e) Note the enricher/IEA correction: global data-center electricity reaches \~945 TWh by 2030 (not 1,200 TWh until \~2035) — v0.1-style "compute demand" claims should use the lower near-term figure.

---

# PART 14 — INDICATORS TO WATCH

- **Electricity/compute:** GW of new generation built per year (US, China, EU, Gulf); data-center interconnection queues; EU-vs-US electricity price gap.
- **AI:** open-weight model global-usage share; frontier-model performance gap; AI-researcher migration flows.
- **Robotics:** annual installations and density by country; humanoid-robot commercialization.
- **Demographics:** births and TFR (does Korea's rebound hold?; does middle-income decline accelerate?); marriage rates; young-adults-with-parents share.
- **Labor:** youth unemployment (China, South Africa, Southern Europe); IT/BPO headcount (India, Philippines); Africa job-creation vs labor-entry.
- **Capital/distribution:** top-1% wealth share; homeownership by age; median real wages vs GDP.
- **Manufacturing hinges:** Mexico *realized* (not announced) FDI + July 2026 USMCA outcome; Vietnam value-chain upgrading.
- **Resource converters:** Saudi non-oil GDP share + PIF returns; Guyana's sovereign-fund governance.
- **Geopolitics:** Strait of Hormuz status; cross-strait tension; tariff regime.
- **State capacity:** infrastructure build times; permitting speed; corruption trends.

---

# PART 15 — MODEL LIMITATIONS

1. **Score precision is illusory.** The 0–100 scores are structured judgments, not measurements; small-state and fragile-state scores are low-confidence. Directions and rankings are more reliable than absolute numbers.
2. **Official-data skepticism applies unevenly.** China (youth-unemployment methodology, GDP), Russia (wartime data), Gulf (migrant-labor exclusion from "median" figures), and most of Sub-Saharan Africa (informal-economy invisibility) all require caution — flagged in-line.
3. **The AI/robotics trajectory is the master uncertainty.** If frontier AI stalls or an AI-capex bubble corrects (the IMF flags "reevaluation of technology expectations" as a key downside), the techno-rentier scenario weakens and the input-inversion thesis slows.
4. **Social-cohesion causal chains are graded weak-to-moderate;** I have avoided asserting that low fertility causes authoritarianism or violence.
5. **2026 shocks (Iran war, tariff regime) are fluid** and could shift energy, trade, and Gulf trajectories materially within the forecast window.
6. **This is a relative-position model.** "Decline" almost always means relative to faster risers, not absolute immiseration — Japan and Western Europe remain among the best places on Earth to be a median citizen even as their global weight falls.
7. **Coverage tradeoff:** breadth (≈all sovereigns) was prioritized per instruction, at the cost of depth for small states; the 38 deep cards carry the analytical weight.

**Bottom line — the question the model was built to answer:** The societies converting technology, capital, demographics and institutions into *both* national power *and* rising median living standards are a narrow set — high-capacity democracies with broad capital ownership and the ability to build (Nordics, Netherlands, Switzerland, Singapore, Australia, Canada; the Gulf converters for their nationals), plus the genuine convergers (India, Vietnam, Poland, and Mexico if it executes on energy). A larger group — the US, China, and the resource states — is gaining national power while leaving median citizens behind or dependent. And the biggest at-risk group is the young, fast-growing, low-capacity states where population outruns jobs. **Technology is not destiny; institutions and ownership decide who benefits.**