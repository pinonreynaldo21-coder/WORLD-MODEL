# Research Materials

- DEEP_RESEARCH_V2_REPORT.md — latest research synthesis.
- DEEP_RESEARCH_V2_RAW.json — raw research artifact with source metadata.
- CLAUDE_BASELINE_REPORT_v1.md — earlier baseline supplied by the user.
- reference_atlas/ — prior World Systems Atlas work; inspiration/reference, not authoritative current model.

`data/source_ledger.csv` was extracted from the deep-research citations.
