# Global Futures Ranking: Technology, Development, Demographics and National Adaptation

## Executive summary

I rebuilt the framework as a **technology- and development-centered global futures model**, using the Claude report you uploaded as the starting baseline rather than accepting its country scores as fixed truth. fileciteturn0file1 The downloadable model now contains **197 analytical country/economy records**: the 193 UN member states, Palestine and the Holy See, plus Taiwan and Kosovo as separately modeled political economies. Every record contains the requested 18 scores, four additional structural variables, composite indexes, 2030/2040/2050 trajectories, archetypes and confidence grades.

The main conclusion is that the future is unlikely to divide neatly into “rich countries win, poor countries lose.” The more useful divide is:

> **Can a society convert electricity, compute, technology, capital, skills, resources, infrastructure and institutional capacity into productivity—and then distribute enough of that productivity to sustain household formation, social stability and political legitimacy?**

That leads to several important revisions of the earlier model.

**Europe is under serious relative-pressure, but “Europe is collapsing” is too crude.** WIPO still places Switzerland, Sweden, the UK, Finland, the Netherlands and Denmark among the world's ten most innovative economies, with Germany 11th and France 13th. Yet the ECB notes that roughly 70% of the EU–US per-capita GDP gap is attributable to lower productivity, with ICT an important contributor. Europe therefore combines exceptional human capital and institutions with slower technology commercialization, fragmented capital markets, aging and heavy regulatory/infrastructure friction. citeturn16search0turn16search4turn8search0

**Demographics are becoming a nearly universal constraint rather than a specifically European one.** The UN estimates global fertility at about 2.25 children per woman in 2024; more than half of countries and areas were already below replacement, and 63 countries or areas had already passed their population peak. Sub-Saharan Africa is the great exception: its population is projected to rise about 79% to roughly 2.2 billion by 2054, while China's population is projected to fall by about 204 million over 2024–2054. citeturn2search0turn2search1turn2search2turn2search6

**The development model itself is changing.** Cheap labor remains useful, but it is becoming less sufficient. The World Bank's AI-development framework emphasizes four foundations—connectivity, compute, context/data and competency/skills—while the IEA expects data-center electricity consumption to more than double to around 945 TWh by 2030. That makes electricity grids, data centers, cloud access, engineering talent and capital increasingly developmental variables rather than merely “technology-sector” variables. citeturn16search12turn18search0turn18search2

**Industrial automation favors countries that already possess industrial ecosystems.** About 542,000 industrial robots were installed globally in 2024, taking the operating stock to roughly 4.66 million. China installed approximately 295,000—54% of the global total—and had more than two million industrial robots operating. South Korea had the world's highest manufacturing robot density at about 1,220 robots per 10,000 manufacturing workers; China had reached about 567, Germany 449 and Japan 446. citeturn1search2turn1search3turn1search6turn1search11

That creates a development paradox:

> A country with 100 million inexpensive workers may be less attractive than before if another country can combine robots, AI, cheap electricity, excellent logistics and a dense supplier ecosystem.

But it does **not** follow that Bangladesh, Cambodia or Africa automatically lose. Clothing, agriculture, construction and many physical jobs automate at different speeds, and inexpensive robots still require capital, maintenance, reliable electricity and managerial competence. The correct variable is **automation vulnerability × adaptation capacity**, not wages alone.

**Young populations are not inherently an advantage either.** The World Bank expects about 1.2 billion young people in developing economies to reach working age over the next decade or so while only about 400 million jobs are currently projected to be created. The ILO estimates global youth unemployment around 12.4% in 2025 and roughly 20% of young people globally as NEET—neither employed nor in education or training. citeturn1search8turn5search0turn5search6

The model therefore splits demographics into:

> **demographic sustainability**  
> versus  
> **labor absorption capacity.**

Nigeria can receive a high demographic-potential score while simultaneously receiving a low labor-absorption score. Japan can receive an awful fertility score but a strong adaptation score because its capital, automation, infrastructure and human capital mitigate the shock.

**The government variable should be state capacity, not “democracy versus dictatorship.”** IMF research covering 108 developing economies finds that stronger state capacity is associated with greater ability to sustain growth and avoid severe collapses, while democratic institutions appear especially useful in limiting the persistence of deep output collapses. Low-capacity autocracy looks particularly vulnerable. This supports a four-way model—high-capacity with feedback, high-capacity with weak feedback, low-capacity with political competition, and low-capacity with weak feedback—rather than assigning a generic “authoritarian efficiency bonus.” citeturn3search0turn3search9

**Regulation needs the same treatment.** The OECD's 2026 work finds widespread concern about cumulative administrative burdens and shows associations between regulatory-compliance costs and weaker productivity/young-firm dynamism, but it explicitly cautions against equating simplification with simply eliminating rules. The best category is therefore **well-regulated and fast**, not “least regulated.” citeturn8search1turn8search2turn8search4turn8search5

**AI's geographic distribution is also less one-sided than a simple “America wins” thesis.** The United States still has extraordinary advantages in private AI investment, frontier firms, capital and data-center infrastructure, while China has enormous strength in scientific output, industrial deployment and robotics. Stanford's 2026 AI Index reports that the measured U.S.–China frontier-model performance gap has become extremely small on major benchmarks. WIPO simultaneously moved China into the global innovation top ten in 2025 while identifying India, Türkiye, Vietnam, the Philippines, Indonesia and Morocco as significant middle-income innovation climbers. citeturn4search0turn4search1turn4search9turn16search0turn16search4

My highest-conviction regional judgment is consequently:

> **North America is structurally underappreciated as an integrated future economic system.**

The United States supplies frontier technology, capital, universities, defense/aerospace, energy and the world's largest high-income consumer market. Canada adds minerals, energy, immigration capacity and human capital. Mexico contributes a large manufacturing ecosystem, a still-younger workforce, two-ocean access, strategic minerals, substantially lower production costs and direct physical integration with the U.S. economy. U.S.–Mexico goods and services trade reached an estimated **$964.1 billion in 2025**, and more than 80% of Mexican goods exports went to the United States in 2024. citeturn9search0

Mexico was therefore the biggest country-level revision in this pass.

The earlier Claude model had Mexico at only **52/100 on technology adaptation, 64 manufacturing, 62 resources and 72 development potential**. My revised values are **64, 76, 80 and 81**, respectively. I also add variables the first model lacked: **97 geographic/market access, 94 diaspora leverage and 88 development-pipeline momentum**. These remain analyst judgments—not observed indexes—but they better represent Mexico's unusual combination of geography, resources, industrial depth and ongoing investment.

The correction is **not** “Mexico is guaranteed to become rich.” Mexico's near-term macro picture remains mediocre: the IMF projected only around 1.5% growth for 2026 in its 2025 Article IV, while the OECD's February 2026 survey projected about 1.4% in 2026 and 1.7% in 2027. The IMF says Mexico's longer-run potential depends on closing infrastructure gaps, strengthening rule of law and deepening external integration. citeturn17search0turn17search18

So Mexico becomes one of the model's clearest examples of:

> **high structural potential × middling execution capacity.**

The investment underway matters because future rankings should not rely only on current GDP. Mexico's 2026–2030 infrastructure program targets about **MXN 5.6 trillion** in public/mixed investment; CFE's transmission plan calls for about **$8.18 billion**, 275 new transmission lines and 524 substation works; the electricity plan targets roughly **29–32 GW** of capacity additions by 2030; and the Tehuantepec corridor is already partly operational. citeturn0search6turn10search1turn10search2turn10search11

That insight generalizes globally:

> **Current position tells us where a country is. Development-pipeline quality tells us whether it is trying to become something else.**

![Modeled Global Futures score distribution](sandbox:/mnt/data/global_futures_v2_2026-08-26/global_futures_score_distribution.png)

The chart above is the distribution of the model's current Global Futures Index. The scores are **structured analyst judgments, not official statistics**, which is why each country receives a confidence grade and why the full dataset is designed to be repeatedly recalibrated rather than treated as a permanent league table.

## Model architecture and evidence

The earlier Claude report did something useful by separating national power from median-citizen welfare, but it still placed too much explanatory weight on current economic status and too little on **geography, diaspora networks, infrastructure actually being built, technology ownership, grid capacity and project-execution probability**. fileciteturn0file1

The revised model uses the requested 18 core scores plus four overlays.

| Metric | What the score actually means |
|---|---|
| **National Power** | Economic scale, military/geopolitical leverage, strategic autonomy, market size and diplomatic reach |
| **Economic Development Potential** | Ability to raise productivity and income over the next 10–25 years |
| **Technology Adaptation** | Ability to deploy AI, robotics, digital systems and advanced production |
| **Technology Ownership** | Domestic ownership/control of important IP, platforms, compute, cloud, chips and technology companies |
| **Manufacturing Depth** | Supplier networks, tooling, components, clusters, industrial know-how and logistics—not merely manufacturing share of GDP |
| **State Capacity** | Ability to execute policy, build infrastructure, collect revenue, administer programs and maintain institutions |
| **Regulatory Efficiency** | Predictability and ability to approve productive activity while maintaining necessary standards |
| **Human Capital** | Education, skills, health, researchers and technical workforce |
| **Energy Position** | Resources + electricity cost + reliability + generation/grid expansion potential |
| **Capital/Finance** | Domestic savings, banks, public markets, VC, institutional capital and access to foreign capital |
| **Demographic Sustainability** | Age structure, fertility, workforce trajectory and migration—not simply “young = good” |
| **Labor Absorption** | Capacity to create productive employment, especially for youth and graduates |
| **Brain Gain/Retention** | Ability to keep domestic talent and attract foreign/returning talent |
| **Resource Value** | Economically/strategically useful natural resources |
| **Resource-Rent Distribution** | Ability to turn resources into broad capital, services and citizen welfare |
| **Housing/Household Formation** | Ability of young adults to form independent households, marry/cohabit and raise children |
| **Political/Social Stability** | Institutional legitimacy, violence/conflict risk and capacity to absorb economic shocks |
| **Median Citizen Prosperity Potential** | Likelihood that economic/technology gains materially improve ordinary household living standards |

Four overlays substantially improve forecasting:

| Added overlay | Why it matters |
|---|---|
| **Geographic / major-market access** | Mexico beside the U.S. is fundamentally different from an equally productive factory economy an ocean away |
| **Diaspora leverage** | Migrants create trade, capital, knowledge, management, entrepreneurship and return-migration networks beyond remittances |
| **Development-pipeline momentum** | Captures what is being built rather than only what exists |
| **Project-execution capacity** | Prevents announcements and speculative megaprojects from receiving the same value as funded construction |

Technology adaptation is built around the World Bank's four AI foundations—connectivity, compute, context/data and competency—supplemented with WIPO innovation metrics, robot deployment, energy availability, domestic technology ownership and project-level compute investment. citeturn16search12turn16search0turn1search2

The reason **technology ownership** is separate from **technology adoption** is critical. A country can become extremely AI-enabled using foreign models, foreign chips, foreign clouds and foreign robots, while most capital income leaves the country. It may nevertheless benefit through productivity and cheaper services, but this is not equivalent to owning the productive assets.

Similarly, I separate **resource value** from **resource-rent distribution** because the IEA finds strategic-mineral refining remains extraordinarily geographically concentrated: excluding rare earths, the average share of the leading refining country rose to roughly 72% in 2025, with China dominant in many refining chains and Indonesia dominant in nickel. Merely possessing ore is therefore much less valuable than possessing mining + refining + engineering + manufacturing. citeturn18search4turn18search8

The composite model is deliberately transparent:

> **National Capability** = mean of power, tech adaptation, tech ownership, manufacturing, state capacity, energy and finance.

> **Development Momentum** = mean of development potential, technology adaptation, state capacity, regulatory efficiency, human capital, labor absorption, brain retention, development-pipeline momentum, execution capacity and geographic access.

> **Citizen Capture** = mean of median prosperity, housing/household formation, resource distribution, human capital, labor absorption and stability.

> **Global Futures Index** = 45% National Capability + 35% Development Momentum + 20% Citizen Capture.

I would **not** ultimately keep equal weights inside those components. Version three should estimate empirical weights using historical 2000–2025 data. But equal-weight subcomponents are preferable now to pretending that we know, for example, that energy is exactly 1.7 times as important as housing.

The evidence system is:

| Grade | Meaning |
|---|---|
| **A** | Primary/official statistics, government project record, regulatory filing, audited filing |
| **B** | High-quality journalism or high-quality research using transparent evidence |
| **C** | Analytical inference/model judgment |

A country's **confidence grade** is separate. “A/B country” means the score has comparatively extensive direct research; “C country” means the current numbers are heavily based on regional/archetype priors and should be specifically researched before making investment or policy conclusions.

This is especially important because current official forecasts themselves disagree. The IMF's July 2026 update put world growth around 3.0% in 2026 and 3.4% in 2027, while the World Bank's June forecast had global growth around 2.5% in 2026 and 2.8% in 2027. Those are not necessarily contradictions—the organizations use different assumptions and frameworks—but they demonstrate why false decimal-level certainty about 2040 is indefensible. citeturn3search2turn3search3turn3search5

The model therefore uses trajectories and scenario bands, not the fiction that a country's 2050 score can currently be known to one decimal place.

```mermaid
flowchart LR
    A[Energy + Grid] --> F[Productive Capacity]
    B[Compute + AI] --> F
    C[Human Capital] --> F
    D[Capital] --> F
    E[State Capacity] --> F

    F --> G[Productivity]
    G --> H[National Power]
    G --> I[Corporate / Capital Income]
    G --> J[Wages + Household Income]

    K[Housing] --> L[Household Formation]
    M[Youth Employment] --> L
    N[Social Trust] --> L
    L --> O[Fertility + Social Reproduction]

    O --> P[Future Labor Force]
    P --> F

    I --> Q{Ownership broad or concentrated?}
    Q -->|Broad| R[High Citizen Capture]
    Q -->|Concentrated| S[GDP rises faster than median welfare]

    E --> T[Infrastructure Execution]
    T --> A
    T --> U[Transport + Ports + Industrial Zones]
    U --> F
```

That is the central causal architecture: **technology is powerful, but technology interacts with energy, institutions, ownership and the household system.**

## Global ranking and regional futures

The first major conceptual correction is that one universal ranking is inadequate. A country can simultaneously rank highly in national power and poorly in household welfare. The dashboard should therefore always expose at least **Power**, **Development**, **Technology**, **Citizen Capture**, and **overall scenario-adjusted outlook**.

My first-pass 2030 structural hierarchy is:

| Category | Countries / regions | Assessment |
|---|---|---|
| **Frontier system powers** | United States, China | Only two countries presently combine continental scale with deep technology, capital, military and industrial ecosystems |
| **Convergence superpower** | India | Scale + demographics + expanding digital/industrial capacity create enormous upside, but jobs and infrastructure remain binding |
| **High-capacity technology states** | Singapore, Switzerland, South Korea, Netherlands, Nordics, Japan, Israel | Very strong adaptation; some face severe demographic constraints |
| **Manufacturing hinge risers** | Mexico, Vietnam, Malaysia, Poland, Morocco, Turkey | Geography/supply-chain shifts can push them up the value chain |
| **Capital-energy adapters** | UAE, Saudi Arabia | Resources and sovereign capital increasingly being converted into compute, technology and diversification |
| **Large underperformers with upside** | Brazil, Indonesia, South Africa, Nigeria | Assets are enormous; conversion into productivity is inconsistent |
| **Demographic-industrial pressure states** | Germany, Italy, Japan, South Korea, China to a lesser degree | Aging collides with established industrial power; automation determines how painful it becomes |
| **Demographic opportunity / employment-risk states** | Nigeria, Ethiopia, Tanzania, Pakistan, DRC | A huge workforce is valuable only if capital, electricity and jobs arrive |
| **Resource-rent risk states** | Angola, Iraq, Algeria, DRC, Nigeria and others | Resource values can rise much faster than citizen incomes |

This regional ordering is not simply today's GDP ordering.

**North America** receives my strongest long-run structural rating. WIPO describes North America as the world's most innovative region, anchored by the U.S. and Canada; USTR data show exceptionally deep U.S.–Mexico supply-chain integration; and Mexico's mineral and manufacturing position substantially complements U.S. technology and capital. citeturn16search1turn9search0turn0search4

**East Asia** is arguably the world's strongest industrial region. China dominates global robot installations, South Korea has the highest robot density, Japan remains an extraordinarily sophisticated manufacturing economy, and Taiwan is central to leading-edge semiconductor fabrication. Its fundamental weakness is demographic: the UN projects very large long-run population contraction across parts of the region. citeturn1search2turn1search6turn2search0turn2search6

**India and Southeast Asia** are where I see the strongest convergence potential. WIPO identifies India and Vietnam as long-running innovation overperformers and notes continued upward movement by Vietnam, the Philippines and Indonesia. The IEA expects electricity demand growth through 2030 of roughly 6.4% annually in India and 5.3% in Southeast Asia, signaling the scale of industrialization, electrification and rising consumption underway. citeturn16search0turn16search9turn18search1

**The Gulf** is evolving from “oil exporter” toward a more interesting category: **resource-to-capital-to-compute converter**. The World Bank notes advanced telecom networks and growing AI/data-center investment throughout the GCC, with Saudi Arabia and the UAE emerging as regional leaders. Saudi projects now include a proposed 1.5-GW DataVolt AI data-center development in Oxagon and a 480-MW government data center in Riyadh. citeturn16search13turn14search7turn14search13

**Europe is better described as a high-income relative decliner than as a loser.** It possesses many of the world's strongest innovation economies, excellent infrastructure and human capital, but its productivity, venture-capital depth, firm scaling and demographics are unfavorable relative to the U.S. and dynamic Asia. The EU fertility rate fell to about 1.34 in 2024, while WIPO still places six European economies in the global top ten for innovation. Both can be true simultaneously. citeturn5search1turn5search2turn16search0turn8search0

**Africa has the widest outcome distribution.** It contains enormous demographic and resource potential but extremely uneven electricity, skills, capital and state capacity. Mission 300 had connected more than 50 million people across 40 countries by June 2026 and aims for 300 million by 2030; the World Bank and AfDB had committed nearly $15 billion with additional co-financing. That is precisely the kind of infrastructure acceleration that can alter our prior assumptions. citeturn15search1turn15search3

The resulting regional relationship map looks more like this:

```mermaid
flowchart TB
    USA[United States<br/>AI + capital + energy] <--> MEX[Mexico<br/>manufacturing + minerals + labor + logistics]
    USA <--> CAN[Canada<br/>energy + minerals + talent]
    MEX <--> ASIA[East / Southeast Asia<br/>components + electronics + industrial FDI]

    CHN[China<br/>industrial + AI + robotics scale] --> ASEAN[ASEAN<br/>China+1 + manufacturing]
    JKT[Japan / Korea / Taiwan<br/>chips + robotics + precision industry] --> ASEAN

    EU[Europe<br/>human capital + advanced industry] --> CEE[Poland / CEE<br/>industrial convergence]
    EU --> MOR[Morocco / North Africa<br/>nearshore production]

    GULF[Gulf<br/>energy + sovereign capital] --> COMPUTE[AI compute + data centers]
    GULF --> INDIA[India<br/>scale + services + manufacturing convergence]

    AFRICA[Africa<br/>young population + minerals] --> M300[Electricity / digital infrastructure]
    M300 --> LEAP[Possible digital / industrial leapfrogging]

    LATAM[South America<br/>food + energy + minerals] --> CRIT[Critical mineral / energy chains]
    CRIT --> CHN
    CRIT --> USA
    CRIT --> EU
```

These linkages increasingly revolve around electricity and strategic materials. The IEA forecasts global data-center electricity demand around 945 TWh in 2030, while critical-mineral refining remains highly concentrated. Countries that can supply **energy + minerals + processing + manufacturing**, rather than only raw commodities, receive a much larger future premium in this version of the model. citeturn18search0turn18search4

**Current rank bands, rather than false-precision ordinal ranks:**

| Question | Leading group in the current model |
|---|---|
| **Most powerful** | U.S., China; then India; then Japan/France/Germany/UK/Russia/South Korea |
| **Fastest structural risers** | India, Vietnam, Mexico, Morocco, Poland, Indonesia, UAE, Saudi Arabia, Turkey, Kazakhstan |
| **Biggest relative-decline risks** | Russia under prolonged isolation, Italy, Germany, Greece, Belarus; Japan/Korea face demographic relative decline despite high living standards |
| **Best technology adapters** | U.S., South Korea, Israel, China, Taiwan, Singapore, Japan, Switzerland/Sweden, UK, UAE |
| **Strongest manufacturing positions** | China; South Korea/Japan/Germany/Taiwan; U.S.; Mexico; Malaysia/Vietnam; Poland; India/Thailand |
| **Strongest energy positions** | Saudi Arabia, UAE/Qatar, U.S., Canada, Norway, Australia, Russia, Brazil, Kazakhstan; China receives a strong infrastructure/buildout score |
| **Best median-citizen structures today** | Switzerland/Nordics/Netherlands, Singapore, Australia, Japan, Canada and other high-capacity advanced states—with housing causing meaningful penalties in several Anglosphere economies |
| **Highest AI/automation business-model exposure** | Philippines and India on service outsourcing; advanced English-speaking service economies on white-collar tasks; Bangladesh/Cambodia and similar economies on longer-run manufacturing automation |

That last category is deliberately **exposure**, not predicted job destruction. Stanford reports rapidly rising organizational AI adoption, but the labor consequences remain highly uncertain; some tasks are substituted while others are complemented. The World Bank's framework likewise emphasizes that developing countries can adapt and innovate rather than simply consume technology. citeturn4search4turn4search10turn16search12

![National power versus citizen capture](sandbox:/mnt/data/global_futures_v2_2026-08-26/national_power_vs_citizen_capture.png)

That scatter is conceptually one of the most important outputs in the project. **The country can win while the median citizen only partially wins.**

The U.S. is the most obvious high-stakes case: extraordinary AI, capital, energy and corporate upside does not automatically solve expensive housing or concentrated capital ownership.

A mineral-rich developing state can be an even more extreme case: commodity exports can raise national income, state revenue and elite wealth while generating comparatively few jobs.

Conversely, Japan could lose relative geopolitical weight while remaining one of the world's safest and most comfortable places for ordinary people.

That is why “winning country” and “winning population” can never be collapsed into one column.

## Technology, demographics and social reproduction

Technology should be treated as a **general-purpose developmental input** comparable to electricity or transport infrastructure, rather than merely as an industry.

The first bottleneck is compute. The World Bank explicitly treats compute as one of its four core AI foundations, and Stanford's 2026 AI work documents an enormous concentration of advanced AI capital and infrastructure in the U.S., while China has become much more competitive at the model and industrial-application level. citeturn16search12turn4search0turn4search1

The second bottleneck is **electricity**. The IEA expects data-center electricity demand to more than double by 2030 and estimates that around half of U.S. electricity-demand growth through 2030 could come from data centers. China alone is expected to add roughly **2,600 TWh of total electricity demand between 2025 and 2030**, approximately equivalent to current EU electricity consumption. India and Southeast Asia are also expected to see strong demand growth. citeturn18search0turn18search1turn18search3

This creates an increasingly powerful formula:

> **Cheap/reliable energy → compute → AI adoption → automation → industrial productivity → capital formation.**

Countries with chronic blackouts or transmission bottlenecks will not be able to fully exploit cheap AI even when model access becomes nearly free.

The third bottleneck is **physical automation**. China is particularly interesting because it combines AI progress with the world's largest manufacturing ecosystem and an enormous robot deployment program. That creates a plausible path by which Chinese manufacturing becomes **more productive while the Chinese workforce shrinks**. citeturn1search2turn1search3turn2search6

The fourth is **domestic value capture**. China is unusually strong here because it increasingly owns not only factories but also robots, batteries, industrial companies, AI models and increasingly sophisticated domestic technology. Mexico is much weaker in ownership even if it becomes a large adopter. The UAE can import enormous technology capacity but increasingly uses sovereign capital to buy ownership claims. India sits somewhere between the two.

WIPO's 2025 ranking illustrates why adoption paths matter: Switzerland, Sweden and the U.S. led globally, but China entered the top ten and middle-income economies including India, Türkiye, Vietnam, the Philippines, Indonesia and Morocco have climbed materially over the longer term. citeturn16search0turn16search9

Demographics then interact with all of this.

The global fertility transition is far more advanced than the intuitive “rich countries are old, developing countries are young” model implies. More than half of countries were already below replacement fertility in 2024. The EU reached only about **1.34 births per woman**, with roughly 3.55 million births in 2024; Spain was around 1.10. citeturn2search0turn5search1turn5search2

But fertility should not be interpreted only through pensions.

I added a dedicated **social-reproduction / household-formation layer** because a society depends on more than replacing workers.

In the United States, Census data show married-couple households fell from roughly **66% of households in 1975 to 47% in 2025**, while one-person households rose from about 20% to 29%. Median first-marriage ages reached approximately 30.8 for men and 28.4 for women. citeturn5search4

That does **not** establish that declining marriage caused economic stagnation. It does establish that the structure of household formation has changed substantially.

The model therefore treats the relationship cautiously:

> housing affordability  
> + youth employment/income  
> + relationship/marriage formation  
> + childbearing costs  
> + desired versus realized fertility  
> + migration  
> → future household and demographic structure.

Housing can plausibly be both an economic and demographic constraint. But family trends are not uniform across countries or generations, so this should be tested rather than assumed.

The loneliness evidence reinforces that caution. WHO's 2025 global work estimates roughly one in six people experience loneliness, with substantially higher reported prevalence among younger people, but OECD evidence shows trajectories differ considerably across countries and some youth indicators have recently improved. The correct conclusion is **social-connection stress deserves measurement**, not “the West is inevitably becoming lonely and collapsing.” citeturn7search3turn7search5

A useful causal map is:

```mermaid
flowchart TD
    A[Housing scarcity / high rent] --> B[Delayed independent household]
    C[Weak youth earnings / unemployment] --> B
    D[Long education / uncertain career] --> B

    B --> E[Later marriage / partnership]
    E --> F[Later first birth]
    F --> G[Lower completed fertility]

    G --> H[Aging + workforce contraction]
    H --> I[Fiscal pressure]
    H --> J[Labor scarcity]
    J --> K[Automation incentive]
    K --> L[Higher productivity potential]

    I --> M[Higher tax / lower benefit pressure]
    M --> N[Young-adult economic pressure]
    N --> B

    O[Immigration] --> H
    P[Housing construction] --> A
    Q[Productivity / wage gains] --> C
```

The interesting possibility is a **negative feedback trap**:

> stagnation → weak youth prospects → delayed households → lower fertility → aging → fiscal pressure → even weaker prospects.

But an equally plausible countercycle exists:

> labor scarcity → higher wages + automation → productivity → cheaper goods / higher incomes → improved household formation.

Our model should track which is actually occurring.

This is also why governments matter.

The state-capacity literature suggests the best predictor is not simply whether a government can issue orders, but whether it can **execute complex policy and correct errors**. citeturn3search0turn3search9

I would classify governance approximately as:

| State form | Developmental strength | Major danger |
|---|---|---|
| **High capacity + strong feedback** | Fast enough execution with error correction | Veto points can still accumulate |
| **High capacity + weak feedback** | Exceptional ability to coordinate infrastructure/industry | Large mistakes can persist or scale |
| **Low capacity + political competition** | Feedback exists | Government may remain unable to build |
| **Low capacity + weak feedback** | Few effective constraints | Corruption, capture and catastrophic policy risk |

Singapore is not successful merely because government is powerful; its bureaucracy and execution capacity matter. China is not successful merely because it is authoritarian; dozens of authoritarian governments are poor. The U.S. is not successful merely because it is democratic; its decentralized private sector, capital markets, universities, immigration and competitive states contribute enormously.

This produces another key future variable:

> **Can government accelerate infrastructure faster than regulation, political vetoes, corruption and administrative fragmentation slow it down?**

The OECD's current regulatory work reinforces that question: administrative burdens have increased across many surveyed economies, and construction/planning is one of the major areas governments are attempting to simplify. citeturn8search1turn8search2turn8search5

That matters most in the exact sectors the future model cares about:

data centers  
housing  
transmission  
power generation  
mines  
semiconductor plants  
factories  
rail  
ports.

## Development pipelines and the Mexico reassessment

The biggest methodological change in this version is a **Development Pipeline Index**.

A project receives separate assessments for:

> stage  
> financing  
> completion probability  
> scale relative to the economy  
> bottleneck removal  
> network effects  
> productivity effect  
> domestic value capture  
> debt burden  
> maintenance burden.

This prevents a government PowerPoint presentation from being scored like infrastructure physically under construction.

A condensed high-impact project table follows. The execution probabilities are **my model priors**, while the project facts and stages come from the cited records.

| Country | Project | Current stage | Model execution probability | Why it could matter |
|---|---|---|---:|---|
| **Mexico** | Plan México infrastructure program | Program/funding underway | **70%** | ~MXN 5.6tn across power, rail, ports, roads, water, health, education and airports. citeturn0search6 |
| **Mexico** | CFE transmission expansion | Funded/implementation | **78%** | ~$8.18bn; 275 lines + 524 substation works attacks a primary industrial/compute bottleneck. citeturn10search1 |
| **Mexico** | Electricity capacity expansion | Pipeline/implementation | **72%** | Roughly 29–32 GW targeted through 2030, depending on program definition. citeturn10search2turn10search11 |
| **Mexico** | Tehuantepec / CIIT | Partly operational/construction | **78%** | Gulf–Pacific rail/ports + industrial zones + eventual Guatemala/Central America connectivity. citeturn0search3turn0search7 |
| **Mexico** | AWS Mexico Central | Operational/expanding | **90%** | Three availability zones; AWS plans >$5bn over 15 years. citeturn11search0 |
| **Mexico** | CloudHQ Querétaro | Announced/preconstruction | **55%** | $4.8bn, six-data-center, 900-MW concept; major upside but tenant/power execution still matter. citeturn11search1turn11news47 |
| **India** | High-speed rail corridors | Budget/preparation | **55%** | Seven corridors totaling roughly 4,000 km are contemplated in the 2026 budget framework. citeturn13search3 |
| **India** | East-West freight corridor | Budget/preparation | **68%** | Proposed 2,052-km dedicated freight corridor can lower internal logistics friction. citeturn13search0turn13search8 |
| **Vietnam** | North–South high-speed rail | Approved/preparation | **62%** | ~1,541 km and ~$67.6bn; potentially transformative national-market integration. citeturn12search1turn12search4 |
| **Vietnam** | Long Thanh airport | Construction/final stages | **88%** | Phase-one capacity aims at 25m passengers and 1.2m tonnes of freight annually. citeturn12search8turn12search10 |
| **Poland** | Port Polska / CPK | Entering construction | **78%** | Integrated new airport/rail/logistics hub; terminal foundation contract signed in 2026. citeturn12search3 |
| **Poland** | Przylądek Pomerania | Construction | **80%** | Major new Baltic container/port infrastructure. citeturn12search16 |
| **Türkiye** | Istanbul North Rail Crossing | Financed/preparation | **82%** | ~$8.3bn, 127-km electrified rail link; World Bank expects very large Bosphorus freight-capacity expansion. citeturn14search1turn15search9 |
| **Kazakhstan** | Middle Corridor rail expansion | Financed/active | **86%** | 322-km greenfield rail project designed to shorten the corridor and enable higher container throughput. citeturn14search0 |
| **Morocco** | Ifahsa pumped hydro | Financed | **88%** | 300 MW storage designed to enable at least another 1 GW of renewable generation. citeturn14search6 |
| **Morocco** | Casablanca metropolitan rail | Financed/implementation | **84%** | 73-km corridor and 15 stations, with both labor-access and freight benefits. citeturn14search5 |
| **Saudi Arabia** | DataVolt Oxagon | Investment/phased | **70%** | $5bn first phase of a planned 1.5-GW AI data-center development. citeturn14search7 |
| **Nigeria** | BRIDGE fiber backbone | Financed | **67%** | >90,000 km of planned fiber could expand the national backbone from ~35,000 to 125,000 km. citeturn15search0 |
| **Ethiopia** | ASCENT electricity access | Financed/implementation | **78%** | Program targets electricity access for nearly six million additional people. citeturn15search2 |
| **Africa** | Mission 300 | Active multinational | **68% overall** | Target of electricity access for 300m Africans by 2030; already >50m connected by June 2026. citeturn15search1 |

Now to Mexico specifically.

Mexico should not be modeled merely as:

> **low-cost factory beside America.**

It has at least **seven simultaneous structural advantages**.

First, **U.S. integration**. U.S.–Mexico goods and services trade reached approximately $964.1 billion in 2025, while supply chains are deeply integrated in autos, electronics, medical devices and other sectors. citeturn9search0

Second, **diaspora integration**. Around 11.1 million Mexico-born people lived in the U.S. in 2024, and approximately 40.5 million U.S. residents traced ancestry or heritage to Mexico. The U.S. is overwhelmingly the principal destination for Mexican emigrants. citeturn10search0

That is not merely a remittance story, although remittances themselves reached approximately **$62.47 billion in 2025**. It is also a network of bilingual workers, managers, entrepreneurs, relatives, capital, customers and potential return migrants. citeturn9search8

Third, **mineral endowment**. USGS reports that Mexico was the world's leading silver producer in 2024 at about 22.8% of global output, second in fluorspar, third in wollastonite, fourth in celestite and among the world's top-ten producers of gold, copper, lead and zinc. citeturn0search4

Fourth, **manufacturing depth**. This is not a new greenfield cheap-labor economy. Mexico already has substantial automotive, electronics, aerospace, medical-device and machinery clusters closely integrated with North American production. citeturn9search0

Fifth, **capital inflow**. Mexico reported a record **$40.87 billion in FDI in 2025**, with new investment rising sharply; U.S. and Canadian investment together represented about 46.9% of total FDI. The caveat is that roughly 67.7% of 2025 FDI was reinvested earnings, so the record should not be interpreted as $40.9 billion of entirely new greenfield capacity. citeturn19search1

Sixth, **digital infrastructure is beginning to thicken**. AWS's Mexico Central region opened in Querétaro in January 2025 with three availability zones and a planned investment exceeding $5 billion over 15 years. CloudHQ has announced another $4.8 billion six-data-center development in Querétaro, although Reuters notes that the latter remained contingent on securing a long-term tenant before full construction proceeds. citeturn11search0turn11news47

Seventh, **the logistics geography is exceptional**. The Tehuantepec corridor links Pacific and Gulf ports through rail and industrial zones, with Line Z operating since 2023, Line FA operating since 2024 and Line K extending toward Guatemala/Central America. citeturn0search3turn0search7

But this needs a reality check.

CIIT is **not currently a Panama Canal substitute**. Mexico reported under one million tonnes of freight across Lines Z and FA in an earlier operating period, whereas the Panama Canal handled 489.1 million PC/UMS tons in FY2025. The units are not perfectly comparable, but the scale difference is so enormous that “Panama replacement” is presently an inappropriate description. citeturn0search2turn19search11

Its bigger potential is:

> **Pacific–Gulf logistics + industrial parks + southern Mexican development + Central American integration.**

That could eventually be more economically valuable to Mexico than simply transshipping containers between oceans.

The resulting Mexico score revision is:

| Metric | Prior Claude v1 | Revised v2 | Change |
|---|---:|---:|---:|
| National Power | 58 | **68** | +10 |
| Economic Development Potential | 72 | **81** | +9 |
| Technology Adaptation | 52 | **64** | +12 |
| Technology Ownership | 38 | **44** | +6 |
| Manufacturing Depth | 64 | **76** | +12 |
| State Capacity | 48 | **52** | +4 |
| Regulatory Efficiency | 50 | **52** | +2 |
| Human Capital | 58 | **62** | +4 |
| Energy Position | 60 | **70** | +10 |
| Capital / Finance | 55 | **64** | +9 |
| Demographic Sustainability | 60 | **64** | +4 |
| Labor Absorption | 58 | **61** | +3 |
| Brain Gain / Retention | 40 | **50** | +10 |
| Resource Value | 62 | **80** | +18 |
| Resource-Rent Distribution | 45 | **48** | +3 |
| Housing / Household Formation | 55 | **56** | +1 |
| Political / Social Stability | 50 | **50** | 0 |
| Median Citizen Prosperity Potential | 60 | **65** | +5 |

And the new variables are:

| Mexico structural overlay | Revised score |
|---|---:|
| **Geographic / major-market access** | **97** |
| **Diaspora leverage** | **94** |
| **Development-pipeline momentum** | **88** |
| **Project-execution capacity** | **58** |

That combination summarizes my Mexico view:

> **The upside is unusually high. The uncertainty is execution.**

The IMF's warning about infrastructure gaps and rule of law keeps Mexico from receiving an 80+ state-capacity score just because impressive projects have been announced. citeturn17search0

## Country profiles and probabilistic futures

These 40 profiles are deliberately compressed “deep cards”: the score trajectories are outputs of the model rather than official forecasts, while the mechanisms reflect the evidence discussed above. The full 197-country table is in the downloadable dataset.

| Country | Base-case future thesis |
|---|---|
| 🇺🇸 **United States** | **System winner, distribution uncertain.** Frontier AI, capital, energy and immigration are exceptional; housing/capital concentration determine how much households capture. |
| 🇨🇳 **China** | **Industrial/technology superpower facing demographic compression.** Robotics and electrification can offset labor decline; household-demand weakness and geopolitics are major constraints. |
| 🇮🇳 **India** | **Largest convergence upside.** Digital capability, scale and infrastructure push are powerful; employment creation, education and infrastructure quality determine whether demographics become dividend or burden. |
| 🇲🇽 **Mexico** | **One of the clearest upward revisions.** North American integration + minerals + manufacturing + diaspora + two-ocean logistics + new infrastructure; security, rule of law, electricity and local ownership are the bottlenecks. |
| 🇩🇪 **Germany** | **Rich, technologically capable relative decliner unless productivity accelerates.** Exceptional industrial base; aging, energy, regulation and Chinese industrial competition create pressure. |
| 🇫🇷 **France** | **More resilient European power.** Nuclear, aerospace, defense, scale and human capital are strong; fiscal/political execution is the drag. |
| 🇬🇧 **United Kingdom** | **High technology/finance potential, weak physical-investment record.** AI, research and finance remain strong; housing, infrastructure and productivity are limiting. |
| 🇮🇹 **Italy** | **High wealth, weak trend.** Industrial niches remain excellent but demographics and long-term productivity are among Europe's hardest combinations. |
| 🇪🇸 **Spain** | **Better current growth than the stereotype, severe demographic challenge.** Renewable energy and services help; fertility, youth employment and productivity remain concerns. |
| 🇵🇱 **Poland** | **Strong European convergence candidate.** Manufacturing, defense spending, infrastructure and Western market access are powerful; demographics become the main long-run brake. |
| 🇷🇺 **Russia** | **Resource/military power with declining diversification potential under prolonged isolation.** Energy and military capacity remain large; demographics, sanctions and technology access constrain civilian development. |
| 🇺🇦 **Ukraine** | **Extremely high variance.** Reconstruction could create a modernization shock; war losses, demographics, migration and security dominate the downside. |
| 🇯🇵 **Japan** | **Relative-power decline without societal collapse.** Capital, automation and state capacity cushion aging; population scale and domestic demand shrink. |
| 🇰🇷 **South Korea** | **Possibly the most technically prepared demographic crisis.** World-leading robotics/R&D/industry can offset labor scarcity, but fertility and household pressure are extreme. |
| 🇹🇼 **Taiwan** | **Technological heavyweight with concentrated geopolitical risk.** Semiconductor power is exceptional; demographic and cross-Strait risks dominate everything else. |
| 🇻🇳 **Vietnam** | **Top manufacturing riser.** Electronics, China+1 supply chains, infrastructure and innovation momentum are compelling; it must graduate from foreign-led assembly into domestic capabilities. |
| 🇲🇾 **Malaysia** | **Semiconductor/data-center hinge economy.** Strong infrastructure and electronics ecosystem; domestic innovation and talent retention determine value capture. |
| 🇮🇩 **Indonesia** | **Large-scale resource/industrial convergence candidate.** Nickel and domestic market size create leverage; institutions, skills and higher-value processing are critical. |
| 🇹🇭 **Thailand** | **Strong existing industry, weaker demographic momentum.** Autos/electronics/tourism are valuable but the country must avoid being squeezed by China, Vietnam and aging. |
| 🇵🇭 **Philippines** | **High digital-human-capital potential with direct GenAI exposure.** English-language BPO can move up the value chain or be materially disrupted by AI agents. |
| 🇸🇬 **Singapore** | **One of the world's best adapters.** State capacity, capital, logistics and technology are exceptional; fertility and dependence on global openness are structural vulnerabilities. |
| 🇦🇺 **Australia** | **Resource + immigration + Asia exposure winner.** Energy/minerals and institutions are excellent; housing costs and weak domestic technology ownership reduce household capture. |
| 🇨🇦 **Canada** | **Extraordinary assets, chronic productivity/housing concern.** Energy, minerals, human capital and U.S. access are excellent; investment/productivity conversion has been weaker than potential. |
| 🇧🇷 **Brazil** | **Persistent giant-upside country.** Food, energy, minerals, population and domestic market are enormous; productivity and state/business execution remain the story. |
| 🇦🇷 **Argentina** | **One of the highest-variance reform cases.** Energy, agriculture, minerals and human capital are unusually good relative to income; macro/institutional credibility determines the outcome. |
| 🇨🇱 **Chile** | **High-quality resource state facing aging.** Copper/lithium and institutions are valuable; domestic processing/technology ownership determine the next stage. |
| 🇹🇷 **Türkiye** | **Geographic/manufacturing/logistics hinge.** Europe–Asia positioning and industrial depth are real advantages; macro and institutional volatility are the key discount. |
| 🇸🇦 **Saudi Arabia** | **Huge capital-to-diversification experiment.** Energy and sovereign capital are unmatched; success depends on whether megaproject spending becomes productive private-sector capability. |
| 🇦🇪 **United Arab Emirates** | **One of the strongest small-state futures.** Capital, logistics, immigration, energy and rapid technology adoption combine exceptionally well; citizen/migrant outcomes must be scored separately. |
| 🇮🇱 **Israel** | **Elite technology base with geopolitical tail risk.** Human capital and startup/R&D depth are extraordinary; security and political cohesion dominate the downside. |
| 🇮🇷 **Iran** | **High latent capability, low realized potential under isolation.** Energy, population and technical talent are substantial; sanctions, institutions and geopolitics suppress value. |
| 🇪🇬 **Egypt** | **Strategic location, difficult employment/debt problem.** Suez and scale matter; capital allocation, public debt, population/jobs and private-sector dynamism remain constraints. |
| 🇲🇦 **Morocco** | **One of Africa's most credible industrial risers.** Europe proximity, autos/aerospace, renewables, ports, digitalization and current infrastructure programs provide multiple reinforcing advantages. |
| 🇳🇬 **Nigeria** | **Enormous upside and enormous employment risk.** Population, entrepreneurship, energy and diaspora matter; electricity, governance, security and job creation decide the trajectory. |
| 🇿🇦 **South Africa** | **Asset-rich but labor-market constrained.** Finance, minerals, universities and industry remain powerful; unemployment and infrastructure/state-capacity failures are severe. |
| 🇰🇪 **Kenya** | **Digital East African hub candidate.** Entrepreneurship, services and regional connectivity are strengths; jobs, electricity scale and industrial depth need to rise rapidly. |
| 🇪🇹 **Ethiopia** | **Huge industrialization possibility with equally huge execution risk.** Population and cheap renewable electricity can matter; skills, stability and access remain enormous constraints. |
| 🇨🇩 **DR Congo** | **Canonical country-rich/citizen-poor risk.** Mineral value is exceptional while state capacity, infrastructure and value capture remain extremely weak. |
| 🇵🇰 **Pakistan** | **Demographic potential can become demographic pressure.** Size and location are valuable, but energy, governance, skills and employment creation need major improvement. |
| 🇧🇩 **Bangladesh** | **Successful old development model facing technological transition.** Garments demonstrated industrial capability; automation means the next stage must involve productivity, diversification and skills. |

The full model's **core world scenarios** are intentionally mutually exclusive and sum to 100%. These probabilities are **subjective priors**, not statistical forecasts.

| Scenario | Prior | Relative winners | Relative losers |
|---|---:|---|---|
| **Multipolar technology blocs** | **28%** | India, Mexico, UAE, Saudi, Singapore, Malaysia, Türkiye, Indonesia | Small economies unable to hedge between standards/blocs |
| **U.S.-led AI/capital dominance** | **27%** | U.S., Mexico, Canada, Japan, Korea, Taiwan, selected Gulf allies | Sanctioned rivals and countries outside U.S. capital/technology architecture |
| **Broad AI abundance / leapfrogging** | **17%** | India, Vietnam, Kenya, Mexico, Morocco, adaptable Southeast Asian/African states | Electricity-poor/conflict-affected/closed states |
| **China-centered industrial + open-model diffusion** | **15%** | China, ASEAN manufacturing, Central Asia, commodity suppliers | Legacy manufacturing unable to compete with Chinese cost/productivity |
| **Fragmentation / shocks / low diffusion** | **13%** | Energy/food-secure and geographically insulated states | Import-dependent, fragile and chokepoint-exposed economies |

Three additional variables should be modeled as **overlays**, because they can occur inside any of the five scenarios:

**Robotics aggressively compresses labor-cost arbitrage** — my current subjective probability of a materially important version by the late 2030s is about **35%**.

**Aging/social-reproduction pressures materially reduce growth in ultra-low-fertility societies beyond today's baseline assumptions** — about **45%**.

**Energy/grid breakthroughs significantly relax the electricity constraint on AI and industrial expansion** — about **30%**.

These are deliberately broad because technology uncertainty compounds very quickly beyond 2035. The IEA's own AI-electricity scenarios range from about 700 TWh to 1,700 TWh of data-center electricity consumption by 2035 depending on uptake, efficiency and energy bottlenecks. citeturn18search0turn18search2

The 2000–2050 conceptual timeline is:

```mermaid
timeline
    title Technology and Development Regime
    2000 : China/WTO globalization deepens
         : Labor-cost arbitrage central
         : Internet becomes mass infrastructure
    2010 : Smartphones + cloud scale
         : Global supply chains deepen
         : Cheap capital / platform economy
    2020 : Pandemic supply-chain shock
         : U.S.–China technology fragmentation
         : Industrial policy returns
    2026 : Frontier AI diffusion
         : Robot deployment accelerates
         : Data-center electricity becomes strategic
         : Critical-mineral and grid constraints rise
    2030 : First major AI/robotics adaptation divergence
         : Manufacturing-hinge states can capture relocation
         : Aging becomes visibly binding in East Asia/Europe
    2040 : Capital + compute + electricity increasingly substitute for routine labor
         : Countries diverge by technology ownership and state capacity
    2050 : Workforce geography radically different
         : Africa holds much larger share of global labor force
         : Aging advanced Asia/Europe highly automated or substantially weaker
```

The UN demographic projections, IEA electricity forecasts, World Bank AI foundations and IFR robotics trends provide the structural anchors for that periodization; the 2030–2050 causal interpretation is ours. citeturn2search0turn18search3turn16search12turn1search2

## Deliverables, uncertainty and the research program

The updated research package is here:

**[Download the complete Global Futures V2 research bundle](sandbox:/mnt/data/Global_Futures_V2_Research_Bundle_2026-08-26.zip)**

Individual core files:

**[Full 197-country/economy scoring dataset — CSV](sandbox:/mnt/data/global_futures_v2_2026-08-26/global_futures_country_scores_v2.csv)**

**[Full country dataset — JSON](sandbox:/mnt/data/global_futures_v2_2026-08-26/global_futures_country_scores_v2.json)**

**[JSON schema](sandbox:/mnt/data/global_futures_v2_2026-08-26/global_futures_schema_v2.json)**

**[2000–2050 timeline schema](sandbox:/mnt/data/global_futures_v2_2026-08-26/timeline_schema_2000_2050.json)**

**[Major national development projects — CSV](sandbox:/mnt/data/global_futures_v2_2026-08-26/major_development_projects_v2.csv)**

**[Scenario matrix — CSV](sandbox:/mnt/data/global_futures_v2_2026-08-26/scenario_matrix_v2.csv)**

**[Mexico baseline versus revised scores — CSV](sandbox:/mnt/data/global_futures_v2_2026-08-26/mexico_baseline_vs_revised.csv)**

**[Full methodology](sandbox:/mnt/data/global_futures_v2_2026-08-26/METHODOLOGY.md)**

**[Interactive 18-metric world heatmap](sandbox:/mnt/data/global_futures_v2_2026-08-26/global_futures_map.html)**

**[Interactive 2026–2050 forecast map/timeline](sandbox:/mnt/data/global_futures_v2_2026-08-26/global_futures_forecast_timeline.html)**

The CSV is also the **compact standardized appendix for every country**, which avoids turning the report body into another 150-row wall of lightly researched prose. The lower-confidence countries remain fully represented but are marked **C** until country-specific research replaces regional/archetype priors.

There is an important limitation in the requested **2000–2050 slider**: I have deliberately **not invented historical 2000 scores** by reverse-engineering today's rankings. The schema supports annual 2000–2050 observations, while the interactive forecast currently uses researched/modelled 2026, 2030, 2040 and 2050 frames. Historical 2000–2025 calibration should be built from real World Bank, UN, IEA, WIPO, IFR, ILO and national-statistical series.

That historical calibration is actually the highest-priority next stage because it lets us answer the question:

> **Which variables really predicted successful development over the last 25 years?**

rather than merely deciding what feels important.

The prioritized research queue should therefore be:

| Priority | Research task | Why it changes the model |
|---|---|---|
| **Highest** | Build 2000–2025 historical panel for the 18 dimensions | Allows empirical calibration of weights and backtesting |
| **Highest** | Replace all C-confidence country scores with country-specific evidence | Removes regional-prior bias from the 197-country table |
| **Highest** | Build global infrastructure/project database with funding/stage updates | Distinguishes genuine modernization from announcements |
| **High** | Build country-level electricity/grid/compute dataset | Likely to become one of the strongest AI-era development predictors |
| **High** | Build fertility/marriage/household/housing panel | Tests the social-reproduction/stagnation thesis rather than assuming it |
| **High** | Build technology-ownership accounts | Separates countries that use AI from countries that own AI-era capital |
| **High** | Quantify AI/robot labor exposure by occupation and export model | Identifies BPO, clerical and manufacturing vulnerability |
| **High** | Create subnational models for the U.S., China, India, Mexico and EU | National averages conceal enormous internal divergence |
| **Medium** | Build diaspora-capital/skill-transfer measures | Mexico, India, Philippines, Nigeria, Poland and others may be mispriced without it |
| **Medium** | Resource-value-chain mapping | Measures ore → refining → component → final-product capture |
| **Medium** | Housing construction/permitting model | Links productivity geography, migration and household formation |
| **Medium** | Political-shock and conflict modules | Necessary for Taiwan, Ukraine, Middle East, Russia and fragile states |

The largest uncertainty is **AI capability itself**. If AI mostly complements skilled labor, advanced human-capital economies do extremely well. If autonomous agents become capable of replacing large portions of routine services, BPO and white-collar exporting countries face much larger disruption. If robotics similarly becomes cheap and general, the low-wage manufacturing ladder changes much more dramatically. The IEA's very broad power-demand sensitivity range illustrates how uncertain even the infrastructure consequences remain. citeturn18search2

The second uncertainty is **adaptation speed**. Technology diffusion can move faster than country rankings suggest. WIPO's evidence that India, Vietnam, Türkiye, the Philippines, Indonesia and Morocco have been notable innovation climbers is exactly why today's technology rankings should not simply be extrapolated to 2040. citeturn16search0turn16search9

The third is **demographic behavioral change**. Demographic momentum is relatively predictable, but future fertility is not fixed. Low birth rates can stabilize or partially recover, migration can offset workforce decline, and automation can reduce the economic need for population growth. The UN's projections should therefore be treated as demographic baselines, not immutable destiny. citeturn2search0turn2search2

The fourth is **project execution**. Mexico illustrates this perfectly. The country now has real and unusually large infrastructure, power, cloud and industrial plans, but current growth is still modest and international institutions continue to identify infrastructure gaps and rule-of-law constraints. Both facts have to live inside the model simultaneously. citeturn17search0turn17search18turn0search6

The fifth is **distribution**. Technology can raise GDP while worsening relative economic security for households that own little capital. Resource booms can do the same. That is why the model never lets GDP or national power substitute for median-citizen outcomes.

And that leads to the core framework I would now use for the entire World Future project:

> **The winners will not simply be the countries with the most people, the most oil, the highest GDP today, the least regulation, or the most AI companies.**

The strongest future systems are likely to be those that successfully combine:

> **energy + compute + technology + manufacturing + capital + human capital + infrastructure + competent government + market access + demographic adaptability**

while also solving a second, separate problem:

> **turning national productivity into affordable housing, rising household wealth, productive employment, family/household formation and broad ownership of the new economy.**

That second problem is why the future of **people** can diverge sharply from the future of their **country**.

And the Mexico reassessment illustrates the value of the model especially well: a conventional GDP-growth forecast sees a middle-income economy currently growing slowly; a structural-development model sees a country sitting beside the United States, integrated with California and Texas, with a 40-million-person U.S. heritage network, deep manufacturing, major mineral resources, two oceans, massive trade integration, record FDI, expanding electricity infrastructure, new cloud/AI capacity and an emerging interoceanic industrial corridor—while simultaneously recognizing security, rule-of-law, grid, education, productivity and domestic-ownership weaknesses. citeturn9search0turn10search0turn0search4turn19search1turn10search1turn11search0turn0search7turn17search0

**That is the level of analysis the 197-country model should ultimately reach for every nation.**