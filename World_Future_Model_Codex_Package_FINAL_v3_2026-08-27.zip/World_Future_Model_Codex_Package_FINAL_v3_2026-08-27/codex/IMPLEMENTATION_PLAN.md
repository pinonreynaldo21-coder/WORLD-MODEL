# Implementation Plan

Phase 1: app shell, country registry, world map, rankings, deep-dive pages.
Phase 2: project pipeline, causal engine, scenario propagation, beneficiary groups.
Phase 3: influence blocs, country-vs-citizen, social reproduction view.
Phase 4: edit/import/export, source/evidence system, testing, responsive polish.

Do not block the app on complete scores. Missing data must be first-class and research can be added continuously.
