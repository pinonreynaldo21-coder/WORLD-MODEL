# Acceptance Tests

Data:
- all 197 records load
- null scores stay null
- evidence grade != model confidence
- historical observations versioned
- project stage visible
- announced != operational

Model:
- power != citizen prosperity
- technology adoption != ownership
- resources != value capture
- youth != automatic dividend
- regime type != state capacity
- shocks propagate through drivers
- user can alter weights
- app explains ranking changes

Scenarios:
- core five scenarios work
- overlays can coexist
- country and domestic-group beneficiaries separate

UX:
- world map desktop/mobile
- compare 4+ countries
- 2026/2030/2040/2050
- project filtering
- source drawer
- falsification indicators on deep dives

Trust:
- model outputs labeled
- uncertainty visible
- no deterministic 2050 claims
