# CODEX MASTER PROMPT — WORLD FUTURE MODEL

Build a production-quality local-first web application called:

# WORLD FUTURE MODEL
**Technology, development, demographics, power blocs and who actually benefits.**

Read:
START_HERE.md
docs/PRODUCT_SPEC.md
docs/MODEL_ENGINE.md
docs/DATA_MODEL.md
docs/WORLD_BLOCS_AND_POLARITY.md
docs/DEMOGRAPHICS_SOCIAL_COHESION.md
data/model_config.json
data/metric_definitions.json
data/country_registry_197.csv
data/future_influence_blocs.json
data/causal_rules.json
research/DEEP_RESEARCH_V2_REPORT.md

## Purpose
This is not just a map or GDP ranking. It is a living causal model of the world from 2026–2050.

Connect:
AI, robotics, compute, chips, energy, grids, manufacturing, minerals, capital, infrastructure, state capacity, regulation, geography, trade, demographics, fertility, relationships/marriage, household formation, housing, youth employment, migration, brain drain/gain, inequality, ownership, social cohesion and geopolitical blocs.

Flagship principle:
A COUNTRY CAN GET STRONGER WHILE ORDINARY PEOPLE STAGNATE.

Always separate:
1. national power
2. productive/economic capacity
3. median-citizen prosperity
4. capital/asset-owner gains

## Country model
Support all 197 country/economy rows and all dimensions in metric_definitions.json.
Missing values must remain visibly missing.
Every score shows confidence.

## Main pages
1 Global Overview
2 World Map
3 Rankings
4 Country Deep Dive
5 Region Comparison
6 Development Pipeline
7 Technology & AI
8 Demographics & Social Reproduction
9 Labor / Youth / Migration
10 Energy / Compute / Resources
11 Manufacturing / Supply Chains
12 World Systems / Influence Blocs
13 Scenario Lab
14 Country vs Citizen
15 Beneficiaries
16 Evidence / Sources
17 Research Backlog
18 Model Settings

## World map
Use React + TypeScript + Vite.
Use MapLibre or react-simple-maps and install a maintained world-atlas/Natural Earth geography package at build time.
Color by metric and year.
Years: 2026, 2030, 2040, 2050.

## Development projects
Use development_projects_seed.csv.
Stages:
announced, funded, tendered, under construction, partially operational, operational, paused, cancelled.
Never score announcements like completed infrastructure.

## Future blocs
Use future_influence_blocs.json.
Visually distinguish formal blocs, production systems, capital-energy hubs, swing regions and influence arenas.

## Scenario lab
Core:
Multipolar Technology Blocs
U.S.-Led AI/Capital Dominance
Broad AI Abundance
China-Centered Industrial/Open Models
Fragmentation/Shocks

Overlays:
robotics shock
aging/social-reproduction drag
energy/grid breakthrough
AI rentier concentration
open-model diffusion
resource supercycle
peaceful reintegration
severe U.S.–China bifurcation

For every scenario show:
country winners/losers
bridge states
industry beneficiaries
domestic population-group winners/losers

## Beneficiary model
Use population_beneficiary_groups.csv.
Model impacts on:
capital owners, median workers, routine white collar, high-skill technical, manufacturing labor, youth, homeowners, renters, pensioners, resource owners, migrants/diaspora, small business.

Label these MODELED IMPACTS, never facts.

## Causal engine
Use causal_rules.json.
Click “Why did this country rise/fall?” and show a reason tree.

## Country vs Citizen
Flagship scatter:
X National Capability
Y Citizen Capture
bubble National Power
border confidence
show 2026→2050 trails.

## Social reproduction
Dedicated view testing:
stagnation + housing + youth insecurity + relationship/marriage decline + low fertility + aging + fiscal pressure + polarization.
Always show confirming evidence, contradiction, uncertainty and falsification.

## Mexico flagship
Use mexico_reassessment.csv.
Model US/Texas/California adjacency, USMCA, manufacturing, minerals, diaspora, ports/Tehuantepec, grid, data centers and industrial clusters AGAINST security, rule of law, water, informality, low tech ownership, fertility decline and execution risk.
Do not hard-code a boom. Display:
HIGH STRUCTURAL POTENTIAL × MIDDLING EXECUTION CAPACITY.


## STRATEGIC TECHNOLOGY SOVEREIGNTY / DOMESTIC PRODUCT FORMATION

Read:
- `docs/TECHNOLOGY_SOVEREIGNTY_AND_DOMESTIC_IP.md`
- `data/global_strategic_technology_projects.csv`
- `data/domestic_product_ip_benchmark.csv`
- `data/mexico_strategic_technology_stack.csv`

Add three dedicated model dimensions:
- Domestic Brand / IP Creation
- Strategic Technology Sovereignty
- Industrial Value-Chain Closure

For a country to receive strong credit, distinguish:
ASSEMBLY → LOCAL SUPPLIERS → DOMESTIC DESIGN/IP → SCALED DOMESTIC BRAND → CORE-COMPONENT / FULL-STACK CAPABILITY.

Do not give the same score to:
- a prototype,
- a foreign factory,
- a commercially scaled domestic brand,
- a globally competitive full-stack technology company.

Show maturity, domestic content, production scale, ownership and evidence.

Mexico flagship additions must explicitly include:
Olinia, Olinia Carga, Olinia battery/electronics localization, Coatlicue, NubeMX, Kutsari, QSM, AWS/CloudHQ Querétaro, Kia EV3, Tehuantepec and Manzanillo-Cuyutlán.

Benchmark Mexico fairly against Togg/Türkiye, VinFast/Vietnam, Proton/Malaysia, Ceer/Saudi Arabia, Neo Motors/Morocco, India, Japan, South Korea and China.

## Rankings
Never one ranking only:
Power
Development
Technology
Tech Ownership
Manufacturing
Energy
Modernization Momentum
Demographics
Labor Absorption
State Capacity
Citizen Prosperity
Citizen Capture
Future Upside
Downside Risk
Bridge-State Value
Multipolarity Benefit
AI Benefit
Robotics Exposure
Resource-Supercycle Benefit

Every rank includes confidence, top drivers and sensitivity.

## Time series
Architecture supports real observations 2000 onward.
Do not fabricate historical scores.
Current seed = 2026; model frames = 2030/2040/2050.

## Editing
User can edit scores/weights, add projects, change execution probability, create scenarios, pin countries, add notes/sources, save locally, export/import full model JSON.

## Tech
React
TypeScript
Vite
Zustand
ECharts/Recharts
MapLibre/react-simple-maps
Zod
Vitest
IndexedDB/localStorage

## Design
Financial Times / Bloomberg / modern geopolitical intelligence.
Dark/light.
Restrained color.
No neon.
No force graph for the world system.

## Finish condition
The app must answer:
1. Why is a country rising/falling?
2. Which mechanisms matter?
3. Who benefits inside it?
4. Which world-system scenario helps/hurts?
5. Which projects could change the trajectory?
6. What evidence supports the model?
7. What would change our mind?

Run codex/ACCEPTANCE_TESTS.md before finishing.


# FINAL v3 STRUCTURAL EXPANSION — MANDATORY

Read FINAL_MISSING_DIMENSIONS_AUDIT, EXPERIENCED_PROSPERITY, SUBNATIONAL_METRO_MODEL, DEMOGRAPHIC_COMPOSITION_MIGRATION and the new seed CSVs.

Add opportunity-access/housing exclusion, pension/fiscal aging, natural-vs-migration demographics, composition/integration scenarios, industrial moat/displacement, bloc coordination, South America resource escape, subnational convergence and current-level-vs-trajectory logic.

EU: do not say all 27 must agree on everything. Most ordinary legislation uses qualified majority; unanimity remains important in selected strategic areas including foreign/security policy, own resources/long-term budget, some tax/social-policy matters, enlargement and treaty revision. Model this as coordination friction.

Demographic identity variables are descriptive only. Never assign inherent positive/negative value to ethnicity/religion.

Every country forecast must now answer: current level; direction; geographic access to opportunity; housing access; aging burden; natural vs migration-driven population change; integration capacity; industrial displacement; bloc coordination; infrastructure gap; resource escape; internal divergence; and who captures gains.
